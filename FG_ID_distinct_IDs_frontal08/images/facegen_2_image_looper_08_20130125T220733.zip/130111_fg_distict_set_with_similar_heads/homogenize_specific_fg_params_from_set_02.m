function [ output_args ] = homogenize_specific_fg_params_from_set_02( n_models, Gs_struct, Ga_struct, Ts_struct, Ta_struct )
%GENERATE_DISTINCT_FGS_OVER_PARA_SET Summary of this function goes here
%  Generate a set of facegen fg models over a specific set of parameters
%  and parameter ranges, try to cover the space


timestamps.(mfilename).start = tic;
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');

in_dir = pwd;
pixel_space_data_in_dir = fullfile(in_dir, '..', '121026_fg_morphing_swad_facegen_exploration', 'out_synzero');


% we only use logical_para_vector, set to zero to exclude parameter
geometry_scale = 5;
texture_scale = 3;
%
Gs_exclude_idx = [1, 2];
Gs_exclude_idx = [1, 2, 3, 5, 7];

Gs_struct.logical_para_vector = ones([1 50]);
Gs_struct.logical_para_vector(Gs_exclude_idx) = 0;
Gs_struct.max_per_para_list = ones([1 50]) * geometry_scale;
Gs_struct.min_per_para_list = ones([1 50]) * -geometry_scale;
%
Ga_exclude_idx = [2, 3];
Ga_struct.logical_para_vector = ones([1 30]);
Ga_struct.logical_para_vector(Ga_exclude_idx) = 0;
Ga_struct.max_per_para_list = ones([1 30]) * geometry_scale;
Ga_struct.min_per_para_list = ones([1 30]) * -geometry_scale;
%
Ts_exclude_idx = [];
Ts_exclude_idx = ones([1 50]);
Ts_struct.logical_para_vector = ones([1 50]);
Ts_struct.logical_para_vector(Ts_exclude_idx) = 0;
Ts_struct.max_per_para_list = ones([1 50]) * texture_scale;
Ts_struct.min_per_para_list = ones([1 50]) * -texture_scale;
%
Ta_exclude_idx = [];
Ta_struct.logical_para_vector = ones([1 30]);
Ta_struct.logical_para_vector(Ta_exclude_idx) = 0;
Ta_struct.max_per_para_list = ones([1 30]) * texture_scale;
Ta_struct.min_per_para_list = ones([1 30]) * -texture_scale;



% no morphs (yet)
StimulusSet_id = ['FG_ID_distinct_IDs_', '01'];	% 
set_suffix = '_01ratios';

% no morphs (yet)
StimulusSet_id = ['FG_ID_distinct_IDs_frontal', '01'];	% 
set_suffix = '_01ratios';
% ready this for unix systems...

[sys_status, host_name] = system('hostname');
switch host_name(1:end-1) % last char of host name result is ascii 10 (LF)
	case 'virt764'
		% virtual windows 7 64 bit under vbox on mac
		FIGURE_FILE_DIR = fullfile('H:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'FG_generated_faces', 'swad_121017', 'Distinct_fg_faces', 'set_01', ['tweened', set_suffix]);
		OUTPUT_DIR = fullfile('H:', 'space', 'data', 'moeller', 'face_project', 'KOFIKO', 'StimulusSet', StimulusSet_id, 'images');
	case 'janus'
		FIGURE_FILE_DIR = fullfile('C:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs', ['tweened', set_suffix]);
		OUTPUT_DIR = fullfile('C:', 'space', 'data', 'moeller', 'face_project', 'KOFIKO', 'StimulusSet', StimulusSet_id, 'images');
	%case 'KOFIKO-USER-23A'
	case 'hms-beagle'
		FIGURE_FILE_DIR = fullfile('/', 'space', 'data_local', 'moeller', 'face_project', 'stim_cit', 'FACE_COLLECTIONS', 'FG_generated_faces', 'swad_121017', 'Distinct_fg_faces', 'set_01', ['tweened', set_suffix]);
		OUTPUT_DIR = fullfile('/', 'space', 'data_local', 'moeller', 'face_project', 'stim_cit', 'FACE_COLLECTIONS', 'FG_generated_faces', 'swad_121017', 'Distinct_fg_faces', 'set_03', ['tweened', set_suffix]);
	otherwise
		error(['Hostname ', host_name(1:end-1), ' not handeled yet']);
end
if ~exist(OUTPUT_DIR, 'dir')
	mkdir(OUTPUT_DIR);
end


% find all models
proto_models = dir(fullfile(FIGURE_FILE_DIR, ['*.fg']));
in_fg_cell = cell([1 length(proto_models)]);
fg_cell = cell([1 length(proto_models)]);
for i_fg = 1 : length(proto_models);
	cur_fg_name = proto_models(i_fg).name;
	cur_fg = fn_handle_fg_models('read', fullfile(FIGURE_FILE_DIR, cur_fg_name));
	in_fg_cell{i_fg} = cur_fg;
	% now remove specific parameters by clamping them to zero (the average model value)
	if ~isempty(Gs_struct) && ~isempty(cur_fg.coordGs) 
		% Gs shape symmetric
		cur_fg.coordGs = cur_fg.coordGs .* Gs_struct.logical_para_vector;
	end
	if ~isempty(Ga_struct) && ~isempty(cur_fg.coordGa) 
		% Ga shape assymetry
		cur_fg.coordGa = cur_fg.coordGa .* Ga_struct.logical_para_vector;
	end
	if ~isempty(Ts_struct) && ~isempty(cur_fg.coordTs) 
		% Ts texture symetric
		cur_fg.coordTs = cur_fg.coordTs .* Ts_struct.logical_para_vector;
	end
	if ~isempty(Ta_struct) && ~isempty(cur_fg.coordTa) 
		% Ta texture assymetry
		cur_fg.coordTa = cur_fg.coordTa .* Ta_struct.logical_para_vector;
	end		
	
	fg_cell{i_fg} = cur_fg;
	% now save it out again
	stat = fn_handle_fg_models('write', fullfile(OUTPUT_DIR, cur_fg_name), cur_fg);
end


% out_dir = fullfile(in_dir, 'out_synzero');
% if ~exist(out_dir, 'dir')
% 	mkdir(out_dir);
% end
% out_dir = fullfile(in_dir, 'out_synzero');



% gat a 2d table of the fg parameters for all models, potentially scale by
% psychophysics discrminability to equalize the fators (if possible)
full_model_para_table = zeros(length(fg_cell), length(fg_cell{1}.coordGs) + length(fg_cell{1}.coordGa) + length(fg_cell{1}.coordTs) + length(fg_cell{1}.coordTa));
disp(['Converting ', num2str(size(full_model_para_table, 1)), ' face gen model structures into a ', num2str(size(full_model_para_table, 1)), ' by ', num2str(size(full_model_para_table, 2)), ' table.']);
for i_fg_cells = 1 : length(fg_cell)
	cur_start = 1;
	full_model_para_table(i_fg_cells, cur_start:cur_start + size(fg_cell{1}.coordGs, 2) - 1) = fg_cell{i_fg_cells}.coordGs;
	cur_start = cur_start + size(fg_cell{1}.coordGs, 2);
	full_model_para_table(i_fg_cells, cur_start:cur_start + size(fg_cell{1}.coordGa, 2) - 1) = fg_cell{i_fg_cells}.coordGa;
	cur_start = cur_start + size(fg_cell{1}.coordGa, 2);
	full_model_para_table(i_fg_cells, cur_start:cur_start + size(fg_cell{1}.coordTs, 2) - 1) = fg_cell{i_fg_cells}.coordTs;
	cur_start = cur_start + size(fg_cell{1}.coordTs, 2);
	full_model_para_table(i_fg_cells, cur_start:cur_start + size(fg_cell{1}.coordTa, 2) - 1) = fg_cell{i_fg_cells}.coordTa;
end

disp('Loading pre computed pixelspace estimates for all fg parameters.');
coord_types_cell = {'coordGs', 'coordGa', 'coordTs'}; % coordTa not implemented yet
% try to load the pixel difference sums for the different coordinates
% as a first proxy about the importance of the components on the faces
pixelspace_data = ones([1 size(full_model_para_table, 2)]);
for i_GTsa_string = 1 : length(coord_types_cell)
	cur_Gs_string = coord_types_cell{i_GTsa_string};
	cur_pixel_scale_data = load(fullfile(pixel_space_data_in_dir, ['FG_', cur_Gs_string,'_pixel_difference_sum_between_extremes' , '.mat']));
	if strcmp(cur_Gs_string, 'coordGs')
		cur_start = 1;
		pixelspace_data(cur_start : cur_start + size(fg_cell{1}.coordGs, 2) - 1) = cur_pixel_scale_data.extremes_abs_diff_sum_by_parameter_list;
	end
	if strcmp(cur_Gs_string, 'coordGa')
		cur_start = 1 + size(fg_cell{1}.coordGs, 2);
		pixelspace_data(cur_start : cur_start + size(fg_cell{1}.coordGa, 2) - 1) = cur_pixel_scale_data.extremes_abs_diff_sum_by_parameter_list;
	end
	if strcmp(cur_Gs_string, 'coordTs')
		cur_start = 1 + size(fg_cell{1}.coordGs, 2) + size(fg_cell{1}.coordGa, 2);
		pixelspace_data(cur_start : cur_start + size(fg_cell{1}.coordTs, 2) - 1) = cur_pixel_scale_data.extremes_abs_diff_sum_by_parameter_list;
	end
	if strcmp(cur_Gs_string, 'coordTa')
		cur_start = 1 + size(fg_cell{1}.coordGs, 2) + size(fg_cell{1}.coordGa, 2) + size(fg_cell{1}.coordTs, 2);
		pixelspace_data(cur_start : cur_start + size(fg_cell{1}.coordTa, 2) - 1) = cur_pixel_scale_data.extremes_abs_diff_sum_by_parameter_list;
	end	
end

% now select the n_models most distinct models and return those
disp(['Performing MDS over ', num2str(size(full_model_para_table, 1)), ' rows.']);
timestamps.(mfilename).int_start = tic;
mds = perform_MDS_analysis(full_model_para_table', 'euclidean', 'single');

timestamps.(mfilename).int_end = toc(timestamps.(mfilename).int_start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).int_end)]);

fh_mds = plot_MDS_results_by_category( mds.Y, (1:1:size(full_model_para_table, 1)), 2, [], [], 'models' );



timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds (', num2str(floor(timestamps.(mfilename).end / 60)), ' min, ', num2str(mod(timestamps.(mfilename).end, 60)),' sec). Done...']);

return
end

function [ fg_cell ] = generate_n_random_fgs(n_fgs, Gs_struct, Ga_struct, Ts_struct, Ta_struct )
disp(['Generating ', num2str(n_fgs),' face gen models']);
fg_cell = cell([1 n_fgs]);

for i_fg = 1 : n_fgs
	cur_fg = fn_handle_fg_models( 'generate_avg_model', 'dummy.fg', [] );
	
	if ~isempty(Gs_struct) && ~isempty(cur_fg.coordGs) 
		% Gs shape symmetric
		cur_fg.coordGs = get_random_by_logical_and_range(Gs_struct.logical_para_vector, Gs_struct.max_per_para_list, Gs_struct.min_per_para_list);
	end
	if ~isempty(Ga_struct) && ~isempty(cur_fg.coordGa) 
		% Ga shape assymetry
		cur_fg.coordGa = get_random_by_logical_and_range(Ga_struct.logical_para_vector, Ga_struct.max_per_para_list, Ga_struct.min_per_para_list);
	end
	if ~isempty(Ts_struct) && ~isempty(cur_fg.coordTs) 
		% Ts texture symetric
		cur_fg.coordTs = get_random_by_logical_and_range(Ts_struct.logical_para_vector, Ts_struct.max_per_para_list, Ts_struct.min_per_para_list);
	end
	if ~isempty(Ta_struct) && ~isempty(cur_fg.coordTa) 
		% Ta texture assymetry
		cur_fg.coordTa = get_random_by_logical_and_range(Ta_struct.logical_para_vector, Ta_struct.max_per_para_list, Ta_struct.min_per_para_list);
	end	
	
	fg_cell{i_fg} = cur_fg;
end

return
end

function [ paralist ] = get_random_by_logical_and_range(cur_logical_para_vector, cur_max_per_para_list, cur_min_per_para_list)
paralist = cur_logical_para_vector;

% 2 standard deviations, should cover 95.4% or real variation
if nargin < 3 || isempty(cur_min_per_para_list)
	cur_min_per_para_list = -2;
end	
if nargin < 2 || isempty(cur_max_per_para_list)
	cur_max_per_para_list = 2;
end	

% allow scalars to fully scale max and min
if iscalar(cur_max_per_para_list)
	cur_max_per_para_list = ones(size(cur_logical_para_vector)) * cur_max_per_para_list;
end
if iscalar(cur_min_per_para_list)
	cur_min_per_para_list = ones(size(cur_logical_para_vector)) * cur_min_per_para_list;
end


vectorized = 1;

if ~(vectorized)
	for i_para = 1 : length(paralist)
		if ~(paralist(i_para))
			continue
		else
			cur_min = cur_min_per_para_list(i_para);
			cur_max = cur_max_per_para_list(i_para);
			paralist(i_para) = cur_min + (cur_max - cur_min) .* rand([1 1]);
		end
	end
else
	% vectorized
	cur_min = cur_min_per_para_list;
	cur_max = cur_max_per_para_list;
	paralist = (cur_min + (cur_max - cur_min) .* rand(size(cur_logical_para_vector))) .* cur_logical_para_vector;
end

return
end

