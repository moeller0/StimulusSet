function [ fg3_generate ] = fg3_define_generate_arguments( set_name )
%FG3_DEFINE_GENERATE_ARGUMENTS Summary of this function goes here
%   Detailed explanation goes here

switch set_name
	case 'default_set'
		% Facial expression. This is one of None, Anger, Disgust, Fear, Sad,
		% Smile_Closed, Smile_Open, or Surprise
		% all leaf values passed to fg3 in CAPS
		fg3_generate.EXPRESSION = 'None';				% None, Anger, Disgust, Fear, Sad, Smile_Closed, Smile_Open, or Surprise
		fg3_generate.IMAGE_SIZE = [640 480];
		fg3_generate.LOG_LEVEL = 0;						% 0 = Most, 4 = None   Defaults to 1.
		fg3_generate.NUMBER_PIXELS_BETWEEN_EYES = 118;	% Number of pixels between eyes of mean face. Each rendered face uses this as a basis. Defaults to 128. with 118 the full face fits the image
		fg3_generate.BACKGROUND_COLOUR = [128 128 128];	% Comma-separated RGB values (R,G,B) to use for background colour. Values range from 0-255 Defaults to 0,0,0.
		fg3_generate.AMBIENT_BRIGHTNESS = 0.25;
		fg3_generate.BLINK_COEFFICIENT = 0;
		fg3_generate.DISTANCE = 3;
		fg3_generate.EXPRESSION_COEFFICIENT = 1;			% Expression coefficient (level) range Defaults to 0,0.5.
		fg3_generate.GAMMA = 2.2;						% Gamma range Defaults to 1.5,2.5.
		fg3_generate.HEAD_TILT = 0;						% Head tilt range. Defaults to -10,10.
		fg3_generate.LIGHT1_AZIMUTH = 0;
		fg3_generate.LIGHT1_BRIGHTNESS = 0.5;
		fg3_generate.LIGHT1_ELEVATION = 0.2;
		fg3_generate.LIGHT2_AZIMUTH = 10;
		fg3_generate.LIGHT2_BRIGHTNESS = 0.5;
		fg3_generate.LIGHT2_ELEVATION = 0.15;
		fg3_generate.LIGHT3_AZIMUTH = -10;
		fg3_generate.LIGHT3_BRIGHTNESS = 0.5;
		fg3_generate.LIGHT3_ELEVATION = 0.15;
		fg3_generate.POSE_AZIMUTH = 0;			% Pose Azimuth range   Defaults to -45,45.
		fg3_generate.POSE_ELEVATION = 10;		% Pose elevation range Defaults to 0,20.
		fg3_generate.TEXTURE_MODULATION = 1;		% Texture modulation range Defaults to 1,1.5.
		fg3_generate.SAVE_DATAFILES = 0;			% Whether to save data files or not. A datafile consists of the physical parameters used to generate an image. Defaults to 1.
		fg3_generate.SEED = 12345;				% Seed for the random number generator. If set to 0, a seed based on the current time is chosen. Defaults to 0.
		fg3_generate.SHRINK_FACTOR = 1;			% Anti-aliasing image shrink factor. Defaults to 1.
		fg3_generate.MUGSHOT = 1;				% Whether or not render a mugshot image. Defaults to 1. (only mugshots use model texture) ALWAYS set to one
		fg3_generate.N_POSES = 1;
		fg3_generate.N_FACES = 1;
		fg3_generate.AVG_FACE = 0;
		fg3_generate.FROM = 0;
	otherwise
		error(['Parameter set ', set_name, ' not defined yet, please add name and set to ', mfilename]);
end


return
end
