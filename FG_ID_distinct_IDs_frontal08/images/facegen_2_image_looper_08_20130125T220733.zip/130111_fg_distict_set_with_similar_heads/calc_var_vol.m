function [] = calc_var_vol(in_dir, in_vol_wildcard, out_dir, out_vol_stem, out_vol_type, vol_id, save_mean_vol, save_std_vol, save_var_vol, tmp_num)
% calculate the std for each voxel from all input volumes
% tested for analyse 3D structurals
% TODO:
%	test for 4D functionals
%	implement better variance calculation method (calc real mean first and only work on the residuals?)
%	maybe only claculate and store the variance image, as the std can
%	always easily be calculated later fromn that, also write out the number
%	of volumes that were averaged into a small log file...

timestamps.(mfilename).start = tic;
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');
mfilepath = fileparts(fq_mfilename);

% for testing
if (nargin == 0),
	in_dir = fullfile('..', '..', 'mri', 'moco_tmp');	% where do the input volumes reside?
	in_vol_wildcard = 'cor-*.nii';						% which volumes to select?
	out_dir = fullfile('..', '..', 'mri');				% where to store the results?
	out_vol_stem = 'raw_rawavg';						% the stam of the output volume (specifiers will be added at the end)
	out_vol_type = 'mgz';								% which format to output?
	vol_id = '';										% arbitrary volume specifier to allow for multiple script invocations wth out overwriting 
	tmp_num = 0;										% not used yet
	save_mean_vol = 1;									% save the mean volume
	save_std_vol = 1;									% save the standard deviation volume
	save_var_vol = 0;									% save the variance volume
	quit_on_return = 0;									% if called from a script exit matlab and return to shell script
	debug = 1;
else
	quit_on_return = 1;
	debug = 0;
end


% matlab's inbuilt std on all volumes in memory is 5 times slower than the
% Knuth approved on-line version (for 16 256x256x240 inputs)
keep_in_vols_in_mem = 0;	% if set to one, read in all volumes in memory and calculate std and mean in memory TODO implement alternative

% get all input file names
[dummy, in_vol_stem, in_ext] = fileparts(in_vol_wildcard);
[pathstr, name, ext, versn] = fileparts('cor-');

if (isempty(in_ext))
	in_vol_struct_list = dir(fullfile(in_dir, [in_vol_stem, '*', '.img']));
	if isempty(in_vol_struct_list)
		in_vol_struct_list = dir(fullfile(in_dir, [in_vol_stem, '*', '.nii']));	% new version of fs produce nii intermediates, good!
	end
else
	in_vol_struct_list = dir(fullfile(in_dir, in_vol_wildcard));
end

n_in_vols = length(in_vol_struct_list);

if ~(n_in_vols)
	disp(['No volumes found with specified wildcard (', in_vol_wildcard, '), bailing out...']);
	if (quit_on_return),
		exit
	end	
	return
end

% loop over the input files and load the volumes
for i_vol = 1 : n_in_vols
	in_vol_name = in_vol_struct_list(i_vol).name;
	disp(['Reading: ', in_vol_name]);
	tmp_mri = MRIread(fullfile(in_dir, in_vol_name));

	if (i_vol == 1),
		vol_dim = size(tmp_mri.vol);
		if (keep_in_vols_in_mem)
			disp('loading all volumes in memory...');
			vol = zeros([vol_dim n_in_vols]);
		else
			disp('calculating results on-line...');
			mean_vol = zeros([vol_dim]);
			delta_vol = zeros([vol_dim]);
			M2_vol = zeros([vol_dim]);
			std_vol = zeros([vol_dim]);
		end
	end
	
	if (keep_in_vols_in_mem)
		if (length(vol_dim) == 3),
			vol(:, :, :, i_vol) = tmp_mri.vol;	% 3d input -> 4d intermediate\
		elseif (length(vol_dim) == 4),
			vol(:, :, :, :, i_vol) = tmp_mri.vol;	% 4d input -> 5d intermediate
		end
	else
		% http://en.wikipedia.org/wiki/Algorithms_for_calculating_variance
		delta_vol = tmp_mri.vol - mean_vol;
		mean_vol = mean_vol + (delta_vol / i_vol);
		M2_vol = M2_vol + (delta_vol .* (tmp_mri.vol - mean_vol));	% the updated mean_vol!
		std_vol = sqrt(M2_vol / (i_vol - 1));	% M2_vol / (i_vol - 1) is the variance
		%mean_vol = mean_vol + (tmp_mri.vol / n_in_vols); % this only gets
		%the final mean right, so not applicable as on-line mean...
	end
end

if (save_var_vol),
	var_vol = M2_vol / (i_vol - 1);
end

if (keep_in_vols_in_mem)
	% do the calculation over the last dimension (wich is in_vol_sequence_number)
	n_intermediate_dims = length(size(vol));
	if (save_std_vol),
		std_vol = std(vol, 0, n_intermediate_dims);
	end
	if (save_mean_vol),
		mean_vol = mean(vol, n_intermediate_dims);
	end
	if (save_var_vol),
		var_vol = var(vol, 0, n_intermediate_dims);
	end
end

% prepare the output volumes
tmp_out_vol = MRIread(fullfile(in_dir, in_vol_struct_list(1).name), 1);	% we will copy the corrected pixel data into this but want the MPRAGE header
if (save_mean_vol),
	disp('Writing mean volume...');
	out_mean_vol = tmp_out_vol;
	out_mean_vol.vol = mean_vol;
	MRIwrite(out_mean_vol, fullfile( out_dir, [out_vol_stem, '_mean', vol_id, '.', out_vol_type]));
end
if (save_std_vol),
	disp('Writing standard deviation volume...');
	out_std_vol = tmp_out_vol;
	out_std_vol.vol = std_vol;
	MRIwrite(out_std_vol, fullfile( out_dir, [out_vol_stem, '_std', vol_id, '.', out_vol_type]));
end
if (save_var_vol),
	disp('Writing variance volume...');
	out_var_vol = tmp_out_vol;
	out_var_vol.vol = var_vol;
	MRIwrite(out_var_vol, fullfile( out_dir, [out_vol_stem, '_var', vol_id, '.', out_vol_type]));
end

% how long did we take?
timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds. Done...']);

if (quit_on_return),
	exit
end	
return

