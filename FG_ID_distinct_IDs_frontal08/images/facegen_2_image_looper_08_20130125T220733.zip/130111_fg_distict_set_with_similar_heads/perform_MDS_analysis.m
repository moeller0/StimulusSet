function [ mds ] = perform_MDS_analysis( unit_category_mean_table, pdist_distance, linkage_method )
%PERFORM_MDS_ANALYSIS Summary of this function goes here
%   Detailed explanation goes here



mds.response_distance_matrix = pdist(unit_category_mean_table', pdist_distance);		% assume euclidean distance for responses...
mds.response_distance_matrix_linkage = linkage(mds.response_distance_matrix, linkage_method);

% todo sort by dendrogram
%imagesc(squareform(mds.response_distance_matrix));
% 		axis(fh_mds, 'image');
% 		xlabel(gca, 'image #');
% 		ylabel(gca, 'image #');

[mds.Y_cmdscale, mds.mds_eigenvals] = cmdscale(mds.response_distance_matrix);
[mds.Y_mdscale, mds.stress, mds.disparities] = mdscale(mds.response_distance_matrix, 10);
mds.Y = mds.Y_cmdscale;

return
end

