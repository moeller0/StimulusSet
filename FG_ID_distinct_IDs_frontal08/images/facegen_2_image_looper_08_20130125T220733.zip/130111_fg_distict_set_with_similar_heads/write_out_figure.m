function [ ret_val ] = write_out_figure(img_fh, outfile_fqn)
%WRITE_OUT_FIGURE save the figure referenced by img_fh to outfile_fqn,
% using .ext of outfile_fqn to decide which image type to save as.
%   Detailed explanation goes here
% write out the data

% check whether the path exists, create if not...
[pathstr, name, img_type] = fileparts(outfile_fqn);
if isempty(dir(pathstr)),
	mkdir(pathstr);
end

switch img_type(2:end)
	case 'pdf'
		% pdf in 7.3.0 is slightly buggy...
		print(img_fh, '-dpdf', outfile_fqn);
	case 'ps'
		print(img_fh, '-depsc2', outfile_fqn);
	case 'tiff'
		% tiff creates a figure
		print(img_fh, '-dtiff', outfile_fqn);
	case 'jpg'
		% tiff creates a figure
		print(img_fh, '-djpeg', outfile_fqn);
	case 'png'
		% tiff creates a figure
		print(img_fh, '-dpng', outfile_fqn);
		% 	case 'tif'
		% 		% tif only creates the image
		% 		% write out the mosaic as image, sadly the compression does not work...
		% 		imwrite(mos, outfile_fqn, img_type, 'Compression', 'none');
	otherwise
		% default to uncompressed images
		disp(['Image type: ', img_type, ' not handled yet...; trying to pass through as print -d', img_type(2:end)]);
		print(img_fh, ['-d', img_type(2:end)]', outfile_fqn);
		% write out the mosaic as image, sadly the compression does not work...
		% 		imwrite(mos, [outfile_fqn, '.tif'], format, 'Compression', 'none');
end

disp(['Saved figure (', num2str(img_fh), ') to: ', outfile_fqn]);
ret_val = 0;
return
end
