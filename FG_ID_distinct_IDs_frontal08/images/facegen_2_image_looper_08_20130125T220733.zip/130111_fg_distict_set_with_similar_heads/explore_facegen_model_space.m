function [ output_args ] = explore_facegen_model_space( input_args )
%EXPLORE_FACEGEN_MODEL_SPACE Summary of this function goes here
%   Detailed explanation goes here
% TODO:
%	also create plots for profile views?
%	compare mean pixel differences between components to scale the
%	magnitudes of each


timestamps.(mfilename).start = tic;
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');
mfilepath = fileparts(fq_mfilename);
run_fg3 = 1;
prepare_plots = 1;
plot_all = 0;	% either all images or only the xtremes plus stat images
fg_parameter_name = 'coordTa'; % coordGa or coordGs or coordTs or (coordTa)

in_dir = pwd;
parameter_value_list = [-10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8 ,9 ,10];

n_par_vals = length(parameter_value_list);
out_dir = fullfile(in_dir, 'out_synzero');
if ~exist(out_dir, 'dir')
	mkdir(out_dir);
end

if ~(ispc)
	run_fg3 = 0; % this will only work under windows...
	prepare_plots = 1;
end

% define the default values for fg3 generate
fg3_struct.generate = fg3_define_generate_arguments('default_set');

% Data paths
fg3_struct.dirs = fg3_define_dirs;

% just load a reference
ref_fg = fn_handle_fg_models('read', fullfile(in_dir, 'zeroGs_sm.fg'));
ref_fg = fn_handle_fg_models('generate_avg_model', fullfile(in_dir, 'avgGs_sm.fg'));
%ref_fg = fn_handle_fg_models('generate_full_zero_model', fullfile(in_dir, 'avgGs_sm.fg'));



cur_img_stack = [];
cur_gray_img_stack = [];
extremes_abs_diff_sum_by_parameter_list = zeros([1 length(ref_fg.(fg_parameter_name))]);
for i_Gs = 1 : length(ref_fg.(fg_parameter_name))
	cur_Gs = i_Gs;
	cur_fg = ref_fg;
	cur_Gs_string = ['FG_', fg_parameter_name, '_', num2str(cur_Gs, '%02d')];
	for i_par_val = 1 : n_par_vals
		cur_val = parameter_value_list(i_par_val);
		cur_fg.(fg_parameter_name)(i_Gs) = cur_val;
		cur_model_name = ['FG_', fg_parameter_name, num2str(cur_Gs, '%02d'), '.', num2str(cur_val, '%06.3f')];
		stat = fn_handle_fg_models('write', fullfile(out_dir, [cur_model_name, '.fg']), cur_fg);
		% now render an image in the default set
		figure_name = [cur_model_name, '-', 'ORI_', 'A', num2str(fg3_struct.generate.POSE_AZIMUTH, '%03d'), '_', 'E', num2str(fg3_struct.generate.POSE_ELEVATION, '%03d')];
		if (run_fg3)
			[status, result] = fg3('generate', fg3_struct, fullfile(out_dir, [cur_model_name, '.fg']));
			if (status ~= 0), disp(result), end
			copyfile(fullfile(fg3_struct.dirs.TMP_DIR, '000000_1.txt'), fullfile(out_dir, [figure_name, '.txt']));
			copyfile(fullfile(fg3_struct.dirs.TMP_DIR, '000000_1.jpg'), fullfile(out_dir, [figure_name, '.jpg']));
		end
		cur_img = imread(fullfile(out_dir, [figure_name, '.jpg']));
		if isempty(cur_img_stack)
			cur_img_stack = zeros([size(cur_img) (n_par_vals)], 'uint8');
			cur_gray_img_stack = zeros([size(cur_img, 1) size(cur_img, 2) (n_par_vals)], 'uint8');
		end
		cur_img_stack(:, :, :, i_par_val) = cur_img;
		cur_gray_img_stack(:, :, i_par_val) = rgb2gray(cur_img);
		
	end
	if (prepare_plots)
		% assemble all images per fi in one plot and save the image
		
		
		cur_img_stack_mean = mean(double(cur_img_stack), 4);
		cur_img_stack_std = std(double(cur_img_stack), 1, 4);
		cur_img_stack_gray_mean = mean(double(cur_gray_img_stack), 3);
		cur_img_stack_gray_std = std(double(cur_gray_img_stack), 1, 3);
		
		% get the absolute difference to the zero image
		cur_img_stack_abs_diff = sum(abs(double(cur_gray_img_stack) - repmat(double(cur_gray_img_stack(:,:, find(parameter_value_list == 0))), [1 1 n_par_vals])), 3);
		cur_extremes_abs_diff = sum(abs(double(cur_gray_img_stack(:,:,1)) - double(cur_gray_img_stack(:,:,size(cur_gray_img_stack, 3)))), 3);
		extremes_abs_diff_sum_by_parameter_list(i_Gs) = sum(cur_extremes_abs_diff(:));
		
		
		cur_parameter_value_list = parameter_value_list;		
		cur_fh = figure;
		if (plot_all)
			for i_par_val = 1 : n_par_vals
				cur_val = cur_parameter_value_list(i_par_val);
				%subplot(1, n_par_vals + 2, i_par_val);
				subplot(ceil((n_par_vals + 2) / 2), 2, i_par_val);
				imagesc(cur_img_stack(:, :, :, i_par_val));
				axis('image');
				axis('off');
				title(['#: ', num2str(cur_Gs, '%02d'), ' = ', num2str(cur_val, '%04.1f')], 'Interpreter', 'none');
			end
			
			subplot(ceil((n_par_vals + 2) / 2), 2, i_par_val + 1);
			imagesc(cur_img_stack_mean);
			axis('image');
			axis('off');
			title(['#: ', num2str(cur_Gs, '%02d'), ' = avg'], 'Interpreter', 'none');
			subplot(ceil((n_par_vals + 2) / 2), 2, i_par_val + 2);
			imagesc(cur_img_stack_std);
			axis('image');
			axis('off');
			title(['#: ', num2str(cur_Gs, '%02d'), ' = std'], 'Interpreter', 'none');
		else
			% negative extreme
			cur_val = cur_parameter_value_list(1);
			subplot(3, 2, 1);
			imagesc(cur_img_stack(:, :, :, 1));
			axis('image');
			axis('off');
			title(['#: ', num2str(cur_Gs, '%02d'), ' = ', num2str(cur_val, '%04.1f')], 'Interpreter', 'none');
			% positive extreme
			cur_val = cur_parameter_value_list(n_par_vals);
			subplot(3, 2, 2);
			imagesc(cur_img_stack(:, :, :, n_par_vals));
			axis('image');
			axis('off');
			title(['#: ', num2str(cur_Gs, '%02d'), ' = ', num2str(cur_val, '%04.1f')], 'Interpreter', 'none');
			% average
			subplot(3, 2, 3);
			imagesc(uint8(cur_img_stack_mean));
			axis('image');
			axis('off');
			title(['#: ', num2str(cur_Gs, '%02d'), ' = avg'], 'Interpreter', 'none');
			% scaled standard deviation
			subplot(3, 2, 4);
			cur_img = cur_img_stack_std;
			cur_gray_img = repmat(cur_img_stack_gray_std, [1 1 3]);
			imagesc(cur_gray_img/max(cur_img_stack_gray_std(:)), [min(cur_img_stack_gray_std(:))/max(cur_img_stack_gray_std(:)) 1]);
			%imagesc(uint8(cur_img));
			axis('image');
			axis('off');
			title(['#: ', num2str(cur_Gs, '%02d'), ' = std'], 'Interpreter', 'none');
			% scaled summed absolute difference from zero model 
			subplot(3, 2, 5);
			cur_gray_img = repmat(cur_img_stack_abs_diff, [1 1 3]);
			imagesc(cur_gray_img/max(cur_img_stack_abs_diff(:)), [min(cur_img_stack_abs_diff(:))/max(cur_img_stack_abs_diff(:)) 1]);
			%imagesc(uint8(cur_img));
			axis('image');
			axis('off');
			title(['#: ', num2str(cur_Gs, '%02d'), ' = abs diff sum'], 'Interpreter', 'none');
			% scaled summed absolute difference between extremes 
			subplot(3, 2, 6);
			cur_gray_img = repmat(cur_extremes_abs_diff, [1 1 3]);
			imagesc(cur_gray_img/max(cur_extremes_abs_diff(:)), [min(cur_extremes_abs_diff(:))/max(cur_extremes_abs_diff(:)) 1]);
			%imagesc(uint8(cur_img));
			axis('image');
			axis('off');
			title(['#: ', num2str(cur_Gs, '%02d'), ' = extremes diff'], 'Interpreter', 'none');
			
			
		end
		% write out the resulting figure
		[output_rect] = format_paper('default_portrait', cur_fh);
		%set(gca, 'LineWidth', 1.0, 'FontName', 'Helvetica', 'FontSize', 12, 'FontWeight', 'bold');	% override the axes default
		[ ret_val ] = write_out_figure(cur_fh, fullfile(out_dir, [cur_Gs_string, '.jpg']));
		% close figure...
		close(cur_fh);
	end	
end

save(fullfile(out_dir, ['FG_', fg_parameter_name, '_pixel_difference_sum_between_extremes' , '.mat']), 'extremes_abs_diff_sum_by_parameter_list');

timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds (', num2str(floor(timestamps.(mfilename).end / 60)), ' min, ', num2str(mod(timestamps.(mfilename).end, 60)),' sec). Done...']);
return
end