function [ out_model_struct, out_raw_model_struct ] = fn_handle_fg_models( command, fg_model_fqn, in_mat_struct )
% either read or write a facegen model into a matlab structure, handles
% type conversions.
% tested with 

out_model_struct = struct();		% the matlab conformed version of the facegen structure (doubles instead of fixed decimal coded in int16), also no count variables
out_raw_model_struct = struct();	% the raw facegen version of the facegen structure (just in case)

if nargin < 2
	disp('Please specify the command string, the facegen modelname to read or write and for writing the matlab model structure');
	return
end


common_fg_struct = define_common_fg_struct('default');
switch command
	case 'read'
		out_raw_model_struct = read_fg(fg_model_fqn, common_fg_struct);
		out_model_struct = convert_raw_2_mat_model(out_raw_model_struct, common_fg_struct);
	case 'write'
		if (nargin < 3)
			disp('Please pass a matlab facegen model structure as third argument...');
			return
		end
		status = write_fg(fg_model_fqn, in_mat_struct, common_fg_struct);
		
	case 'generate_avg_model'
		out_model_struct = generate_model_struct_for_avg(fg_model_fqn, common_fg_struct);	
		
	case 'generate_full_zero_model'
		out_model_struct = generate_model_struct_for_zero(fg_model_fqn, common_fg_struct);
		
	case 'generate_random_model'
		out_model_struct = generate_random_model_struct(fg_model_fqn, common_fg_struct);
		
	otherwise
		disp(['FaceGen model operation: ', command, ' not implemted (yet)...']);
end

return
end

function [fg_struct] = read_fg(fg_fqn, common_fg_struct)
% load an fg file, ... Looking at FaceGen SDK 3.5 the following might
% actually work...
% TODO
%	implement reading of initial fg
%	error handling

% get access to the data
fg_fh = fopen(fg_fqn, 'r');
if (fg_fh == -1),
	error(['Could not open ', fg_fqn]);
end

% file size
fseek(fg_fh, 0, 'eof');
fsize = ftell(fg_fh);
fseek(fg_fh, 0, 'bof');

% fg files seem to have a magic cookie: FRFG0001 (the fifth or sixth char of which
% might indicate encryption)
fg_struct.FAN_FG_FILE_ID = common_fg_struct.FAN_FG_FILE_ID;	% taken from FanFgFile.cpp
fg_struct.FAN_FG_SCALE = common_fg_struct.FAN_FG_SCALE;		% taken from FanFgFile.cpp
fg_struct.scale_factor = common_fg_struct.scale_factor;		% taken from FanFgFile.cpp

fg_struct.fg_fqn = fg_fqn;
% read the header
fg_struct.magic_cookie = fread(fg_fh, [1, 8], 'uint8=>char');	% TODO compare the encryption position...
% the next set is all unsigned long on 
fg_struct.egmKey = fread(fg_fh, 1, 'uint32=>uint32');			% //! The geometric basis version
fg_struct.egtKey = fread(fg_fh, 1, 'uint32=>uint32');			% //! The texture basis version
fg_struct.numGs = fread(fg_fh, 1, 'uint32=>uint32');			% number of symmetric geometry values
fg_struct.numGa = fread(fg_fh, 1, 'uint32=>uint32');			% number of asymmetric geometry values
fg_struct.numTs = fread(fg_fh, 1, 'uint32=>uint32');			% number of symmetric texture values
fg_struct.numTa = fread(fg_fh, 1, 'uint32=>uint32');			% number of asymmetric texture values
fg_struct.numResiduals = fread(fg_fh, 1, 'uint32=>uint32');		% this should be ZERO
fg_struct.detailTexture = fread(fg_fh, 1, 'uint32=>uint32');	%

% read the face coordinates
% FG wants the values as floats but stores them as shorts, take care of
% this during loading
if (fg_struct.numGs),
	fg_struct.coordGs_short = fread(fg_fh, [1, double(fg_struct.numGs)], 'int16=>int16');	%
end
if (fg_struct.numGa),
	fg_struct.coordGa_short = fread(fg_fh, [1, double(fg_struct.numGa)], 'int16=>int16');	%
end
if (fg_struct.numTs),
	fg_struct.coordTs_short = fread(fg_fh, [1, double(fg_struct.numTs)], 'int16=>int16');	%
end
if (fg_struct.numTa),
	fg_struct.coordTa_short = fread(fg_fh, [1, double(fg_struct.numTa)], 'int16=>int16');	%
end

% if there is a detail texture load it as well
if (fg_struct.detailTexture),
	fg_struct.num_char_detailTexJpeg = fread(fg_fh, 1, 'uint32=>int32');	%JPEG buffer size
	fg_struct.detailTexJpeg = fread(fg_fh, [1, double(fg_struct.num_char_detailTexJpeg)], 'uint8=>uint8'); %
end

% clean up
fclose(fg_fh);

return
end

function [ mat_model_struct ] = convert_raw_2_mat_model( raw_model_struct, common_fg_struct )
% convert the raw fg structure (with C typing of parameters) to proper
% matlab structure

mat_model_struct.fg_fqn = raw_model_struct.fg_fqn;	% keep the source model file in memory...
mat_model_struct.egmKey = raw_model_struct.egmKey;
mat_model_struct.egtKey = raw_model_struct.egtKey;

% no header information required for matlab... sincer we know the lengths
% of all arrays
if (raw_model_struct.numGs),
	mat_model_struct.coordGs = double(raw_model_struct.coordGs_short) * common_fg_struct.scale_factor;
else
	mat_model_struct.coordGs = [];
end

if (raw_model_struct.numGa),
	mat_model_struct.coordGa = double(raw_model_struct.coordGa_short) * common_fg_struct.scale_factor;
else
	mat_model_struct.coordGa = [];
end

if (raw_model_struct.numTs),
	mat_model_struct.coordTs = double(raw_model_struct.coordTs_short) * common_fg_struct.scale_factor;
else
	mat_model_struct.coordTs = [];
end

if (raw_model_struct.numTa),
	mat_model_struct.coordTa = double(raw_model_struct.coordTa_short) * common_fg_struct.scale_factor;
else
	mat_model_struct.coordTa = [];
end

% if there is a detail texture load it as well
if (raw_model_struct.detailTexture),
	%mat_model_struct.num_char_detailTexJpeg = raw_model_struct.num_char_detailTexJpeg;
	mat_model_struct.detailTexJpeg = raw_model_struct.detailTexJpeg;	% for the time being just copy the JPEG blob, to allow at least exchange
else
	%mat_model_struct.num_char_detailTexJpeg = 0;
	mat_model_struct.detailTexJpeg = [];
end

return
end




function [status] = write_fg(fg_fqn, in_mat_struct, common_fg_struct)
% write out a matlab fg structure into a facegen model file...
status = 1;

% get access to the data
fg_fh = fopen(fg_fqn, 'w');	% this truncates prior to writing...
if (fg_fh == -1),
	error(['Could not open ', fg_fqn]);
end

% write the header
counts.magic_cookie = fwrite(fg_fh, common_fg_struct.FAN_FG_FILE_ID, 'uint8');	% TODO compare the encryption position... the magic cookie
% the next set is all unsigned long on 
counts.egmKey = fwrite(fg_fh, in_mat_struct.egmKey, 'uint32');			% //! The geometric basis version
counts.egtKey = fwrite(fg_fh, in_mat_struct.egtKey, 'uint32');			% //! The texture basis version
counts.numGs = fwrite(fg_fh, length(in_mat_struct.coordGs), 'uint32');	% number of symmetric geometry values
counts.numGa = fwrite(fg_fh, length(in_mat_struct.coordGa), 'uint32');	% number of asymmetric geometry values
counts.numTs = fwrite(fg_fh, length(in_mat_struct.coordTs), 'uint32');	% number of symmetric texture values
counts.numTa = fwrite(fg_fh, length(in_mat_struct.coordTa), 'uint32');	% number of asymmetric texture values
counts.numResiduals = fwrite(fg_fh, 0, 'uint32');						% this should be ZERO, just force it...
if isempty(in_mat_struct.detailTexJpeg)
	counts.detailTexture = fwrite(fg_fh, 0, 'uint32');	%
else
	counts.detailTexture = fwrite(fg_fh, 1, 'uint32');	%
end

% read the face coordinates
% FG wants the values as floats but stores them as shorts, take care of
% this during loading
if ~isempty(in_mat_struct.coordGs),
	counts.coordGs = fwrite(fg_fh, (in_mat_struct.coordGs * common_fg_struct.FAN_FG_SCALE), 'int16');	%
end

if ~isempty(in_mat_struct.coordGa),
	counts.coordGa = fwrite(fg_fh, (in_mat_struct.coordGa * common_fg_struct.FAN_FG_SCALE), 'int16');	%
end

if ~isempty(in_mat_struct.coordTs),
	counts.coordTs = fwrite(fg_fh, (in_mat_struct.coordTs * common_fg_struct.FAN_FG_SCALE), 'int16');	%
end

if ~isempty(in_mat_struct.coordTa),
	counts.coordTa = fwrite(fg_fh, (in_mat_struct.coordTa * common_fg_struct.FAN_FG_SCALE), 'int16');	%
end

% if there is a detail texture write it as well
if ~isempty(in_mat_struct.detailTexJpeg),
	counts.num_char_detailTexJpeg = fwrite(fg_fh, length(in_mat_struct.detailTexJpeg), 'int32');	%JPEG buffer size, get from actual buffer
	counts.detailTexJpeg = fwrite(fg_fh, in_mat_struct.detailTexJpeg, 'uint8'); %
end
% clean up
fclose(fg_fh);

return
end


function [ common_fg_struct ] = define_common_fg_struct( version_string )

if ~(nargin)
	version_string = 'default';
end

common_fg_struct.FAN_FG_FILE_ID = '';					% taken from FanFgFile.cpp
common_fg_struct.FAN_FG_SCALE = [];						% taken from FanFgFile.cpp
common_fg_struct.scale_factor = [];	% taken from FanFgFile.cpp

switch version_string
	case 'default'
		% define these only once... (needed for conversion and writing)
		common_fg_struct.FAN_FG_FILE_ID = 'FRFG0001';					% taken from FanFgFile.cpp
		common_fg_struct.FAN_FG_SCALE = 1000.0;						% taken from FanFgFile.cpp
		common_fg_struct.scale_factor = 1.0 / common_fg_struct.FAN_FG_SCALE;	% taken from FanFgFile.cpp
	otherwise
		error(['Common FG structure version. ', version_string, ' not implemented yet...']);
end

return
end


function [ out_model_struct ] = generate_model_struct_for_avg( fg_model_fqn, common_fg_struct )


out_model_struct.fg_fqn =  fg_model_fqn;	% not needed
out_model_struct.egmKey = uint32(2001060901);		% just fill this with something and revisit if things break
out_model_struct.egtKey = uint32(81);				% see above
out_model_struct.coordGs = zeros([1 50]);
out_model_struct.coordGa = zeros([1 30]);
out_model_struct.coordTs = zeros([1 50]);
out_model_struct.coordTa = []; %zeros([1 30]);	% seems to be empty for an facegen model generated avg face model
out_model_struct.detailTexJpeg = [];


return
end

function [ out_model_struct ] = generate_model_struct_for_zero( fg_model_fqn, common_fg_struct )
% this will fail! as coordTa needs to be empty???

out_model_struct.fg_fqn =  fg_model_fqn;	% not needed
out_model_struct.egmKey = uint32(2001060901);		% just fill this with something and revisit if things break
out_model_struct.egtKey = uint32(81);				% see above
out_model_struct.coordGs = zeros([1 50]);
out_model_struct.coordGa = zeros([1 30]);
out_model_struct.coordTs = zeros([1 50]);
out_model_struct.coordTa = zeros([1 30]); %zeros([1 30]);	% seems to be empty for an facegen model generated avg face model
out_model_struct.detailTexJpeg = [];


return
end


function [ out_model_struct ] = generate_random_model_struct( fg_model_fqn, common_fg_struct )
% this will fail! as coordTa needs to be empty???

out_model_struct = generate_model_struct_for_avg('dummy.fg', common_fg_struct );

if ~isempty(Gs_struct) && ~isempty(out_model_struct.coordGs)
	% Gs shape symmetric
	out_model_struct.coordGs = get_random_by_logical_and_range(ones(size(out_model_struct.coordGs)), 2, -2);
end
if ~isempty(Ga_struct) && ~isempty(out_model_struct.coordGa)
	% Ga shape assymetry
	out_model_struct.coordGa = get_random_by_logical_and_range(ones(size(out_model_struct.coordGa)), 2, -2);
end
if ~isempty(Ts_struct) && ~isempty(out_model_struct.coordTs)
	% Ts texture symetric
	out_model_struct.coordTs = get_random_by_logical_and_range(ones(size(out_model_struct.coordTs)), 2, -2);
end
if ~isempty(Ta_struct) && ~isempty(out_model_struct.coordTa)
	% Ta texture assymetry
	out_model_struct.coordTa = get_random_by_logical_and_range(ones(size(out_model_struct.coordTa)), 2, -2);
end


return
end



function [ paralist ] = get_random_by_logical_and_range(cur_logical_para_vector, cur_max_per_para_list, cur_min_per_para_list)
paralist = cur_logical_para_vector;

% 2 standard deviations, should cover 95.4% or real variation
if nargin < 3 || isempty(cur_min_per_para_list)
	cur_min_per_para_list = -2;
end	
if nargin < 2 || isempty(cur_max_per_para_list)
	cur_max_per_para_list = 2;
end	

% allow scalars to fully scale max and min
if iscalar(cur_max_per_para_list)
	cur_max_per_para_list = ones(size(cur_logical_para_vector)) * cur_max_per_para_list;
end
if iscalar(cur_min_per_para_list)
	cur_min_per_para_list = ones(size(cur_logical_para_vector)) * cur_min_per_para_list;
end


vectorized = 1;

if ~(vectorized)
	for i_para = 1 : length(paralist)
		if ~(paralist(i_para))
			continue
		else
			cur_min = cur_min_per_para_list(i_para);
			cur_max = cur_max_per_para_list(i_para);
			paralist(i_para) = cur_min + (cur_max - cur_min) .* rand([1 1]);
		end
	end
else
	% vectorized
	cur_min = cur_min_per_para_list;
	cur_max = cur_max_per_para_list;
	paralist = (cur_min + (cur_max - cur_min) .* rand(size(cur_logical_para_vector))) .* cur_logical_para_vector;
end

return
end

