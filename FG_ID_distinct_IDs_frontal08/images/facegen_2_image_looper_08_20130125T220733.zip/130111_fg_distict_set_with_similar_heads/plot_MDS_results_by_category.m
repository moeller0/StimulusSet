function [ fh_mds ] = plot_MDS_results_by_category( mds_Y, img_category_idx, dimensionality, color_list, marker_list, title_string )
%PLOT_MDS_RESULTS_BY_CATEGORY Summary of this function goes here
%   Detailed explanation goes here

if nargin < 3
	dimensionality = 2;
end

cat_nums = unique(img_category_idx);
n_cats = length(cat_nums);

if (nargin < 4) || isempty(color_list)
	%color_list = [1 0 0];
	if n_cats <= 7
		color_list = lines(7);
	else
		color_list = colorcube(n_cats + 1); % contains white...
		white_idx = find(color_list(:,1) == 1 & color_list(:,2) == 1 & color_list(:,3) == 1);
		if ~isempty(white_idx)
			color_list(white_idx, :) = [];
		end
	end
else
	% make sure to only use the colors for existing categories
	color_list = color_list(unique(img_category_idx), :);
end

if (nargin < 5) || isempty(marker_list)
	marker_list = {'.'};
else
	% make sure to only use the markers for existing categories
	marker_list = marker_list(unique(img_category_idx));
end

opts.PARA_name = '';
opts.by_type = '';

switch dimensionality
	case 3
		MDS_plot_3D = 1;
	otherwise
		MDS_plot_3D = 0;	% default is 2D...
end



%set(0, 'DefaultAxesLineWidth', 2.0, 'DefaultAxesFontName', 'Helvetica', 'DefaultAxesFontSize', 24, 'DefaultAxesFontWeight', 'bold');
%fh_mds = figure('Name', [opts.PARA_name, 'MDS plot', opts.by_type]);
fh_mds = figure('Name', title_string);

%legend_string = {};
hold on;


for i_cat = 1 : n_cats
	img_in_cur_cat_idx = find(img_category_idx == cat_nums(i_cat));

	% get the current color, cycle through the defined colors
	i_color = mod(i_cat, size(color_list, 1));
	if i_color == 0
		i_color = size(color_list, 1);
	end
	
	% get the current marker, cycle through the defined markers
	i_marker = mod(i_cat, size(marker_list, 2));
	if i_marker == 0
		i_marker = size(marker_list, 2);
	end
	
	
	% only plot existing data
	if ~isempty(img_in_cur_cat_idx)
		if (MDS_plot_3D && size(mds_Y, 2) >= 3)
			plot3(mds_Y(img_in_cur_cat_idx, 1), mds_Y(img_in_cur_cat_idx, 2), mds_Y(img_in_cur_cat_idx, 3), 'color', color_list(i_color, :), 'linestyle', 'none', 'LineWidth', 1, 'Marker', marker_list{i_marker}, 'Markersize', 12);
		else
			plot(mds_Y(img_in_cur_cat_idx, 1), mds_Y(img_in_cur_cat_idx, 2), 'color', color_list(i_color, :), 'linestyle', 'none', 'LineWidth', 1, 'Marker', marker_list{i_marker}, 'Markersize', 12);
		end
	end
end


%legend(legend_string, 'Interpreter', 'none',  'Box', 'off', 'Color', 'none', 'Location', 'NorthWest', 'FontSize', 12);
hold off;
xlabel(gca, 'MDS dimension 1', 'FontSize', 14);
ylabel(gca, 'MDS dimension 2', 'FontSize', 14);
if (MDS_plot_3D)
	zlabel(gca, 'MDS dimension 3', 'FontSize', 14);
	
end
title(title_string, 'Interpreter', 'none');
axis equal;




return
end

