function [ output_args ] = tween_by_dir_MAIN( input_args )
%TWEEN_TESTER Summary of this function goes here
%   Detailed explanation goes here
timestamps.(mfilename).start = tic;
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');
mfilepath = fileparts(fq_mfilename);


save_code = 1;
% ready this for unix systems...
[sys_status, host_name] = system('hostname');
switch host_name(1:end-1) % last char of host name result is ascii 10 (LF)
	case 'virt764'
		% virtual windows 7 64 bit under vbox on mac
		src_dir = fullfile('H:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs');
	case 'janus'
		src_dir = fullfile('C:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs');
	%case 'KOFIKO-USER-23A'
	%	src_dir = fullfile('C:', 'Kofiko', 'Data', 'Logs', 'Spiderman', 'ANALYZE_ME');
	case 'hms-beagle'
		src_dir = fullfile('/', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs');
	otherwise
		error(['Hostname ', host_name(1:end-1), ' not handeled yet']);
end

out_dir = fullfile(src_dir, 'tweened');

tween_ratios_list = [0.0, 0.1667, 0.3333, 0.5, 0.6667, 0.8333, 1.0];
tween_ratios_list = [0.0, 0.1667, 0.3333, 0.475, 0.525, 0.6667, 0.8333, 1.0];

out_dir = [out_dir, '_', num2str(length(tween_ratios_list), '%02d'), 'ratios'];

fg_morpher(src_dir, out_dir, tween_ratios_list);

%fg_morpher(src_dir, out_dir, [0.0]);


% saving the code that generated the outpput into the output directory...
if (save_code)
	disp('Saving all matlab code that generated the outputs into the output directory');
	mfile_fqn = mfilename('fullpath');
	code_dir = fileparts(mfile_fqn);
	% save the code in a versioned directory...
	%gzip(code_dir, fullfile(dirs.out_img_lists, [mfilename, '_',
	%datestr(clock, 30)]));	% this compressed each file individually
	zip(fullfile(out_dir, [mfilename, '_', datestr(clock, 30), '.zip']), code_dir); % compresses all files into one archive
end

timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds. Done...']);
return
end