function [ output_args ] = cluster_FGs( input_args )
%CLUSTER_FGS cluster all FGs
%   to figure out one "good" separation between different faces in a test
%   set they should cover the available face-space somewhat evenly
%	lets try to cluster by the facegen parameter vectors


calling_dir = pwd;
in_dir = fullfile(calling_dir, 'lib', 'IDs');
out_dir = fullfile(calling_dir, 'IDs');
% out_dir = fullfile(calling_dir, 'AM_localiser_01');
n_classes = 50;	% how many classes do we want
out_file = ['distinctest_', num2str(n_classes), '_fg_names.txt'];


debug = 1;
if ~isdir(out_dir),
	mkdir(out_dir);
end

% get all existing input fg modells
in_fg_list = dir(fullfile(in_dir, '*.fg'));
n_modells = length(in_fg_list);
fg = cell([1, n_modells]);
fg_names = {};

for i_fg = 1:n_modells
	cur_in_name = in_fg_list(i_fg).name;
	if (debug)
		disp(['Current fg file: ', cur_in_name]);
	end
	fg{i_fg}.name = cur_in_name;
	fg_names{i_fg} = cur_in_name;
	fg{i_fg} = read_fg(fullfile(in_dir, cur_in_name));
end

% preallocate arrays before growing
Gs_array = zeros([fg{1}.numGs, n_modells]);
Ga_array = zeros([fg{1}.numGa, n_modells]);
Ts_array = zeros([fg{1}.numTs, n_modells]);
% now collect the feature vectors, assume all modells to be equal
for i_fg = 1:n_modells
	Gs_array(:, i_fg) = fg{i_fg}.coordGs;
	Ga_array(:, i_fg) = fg{i_fg}.coordGa;
	Ts_array(:, i_fg) = fg{i_fg}.coordTs;
end

% get some clustering
n_cluster = 50;	% I want 50 IDs
dist_type = 'correlation';	% euclidean seuclidean correlation spearman
link_type = 'average';	% single average
fgvalues_by_ID_array = [Gs_array; Ga_array; Ts_array];	% which values to use for getting the clusters
[cluster_out]= cluster_fgs(fgvalues_by_ID_array, fg_names, n_cluster, dist_type, link_type, debug);
[cluster_center_ID_list] = find_fg_closest_2_cluster_mean(fgvalues_by_ID_array, fg_names, cluster_out.cluster_T);
% [cluster_center_ID_list_Gs, ID_2_cluster_relation_Gs]= cluster_fgs(Gs_array, fg_names, n_cluster, dist_type, link_type, debug);
% [cluster_center_ID_list_Ga, ID_2_cluster_relation_Ga]= cluster_fgs(Ga_array, fg_names, n_cluster, dist_type, link_type, debug);
% [cluster_center_ID_list_Ts, ID_2_cluster_relation_Ts]= cluster_fgs(Ts_array, fg_names, n_cluster, dist_type, link_type, debug);

% now save the list of distinctest fg modells...
out_fh = fopen(fullfile(out_dir, out_file), 'w');
if (out_fh == -1),
	error('Could not open out file.')
end
for i_cluster = 1:length(cluster_center_ID_list)
	fprintf(out_fh, '%s\n', cluster_center_ID_list{i_cluster});
end

% clean up
fclose(out_fh)

disp('Done...');
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fg_struct] = read_fg(fg_fqn)
% load an fg file, ... Looking at FaceGen SDK 3.5 the following might
% actually work...
% TODO
%	implement reading of initial fg
%	error handling

% get access to the data
fg_fh = fopen(fg_fqn, 'r');
if (fg_fqn == -1),
	error(['Could not open ', fg_fqn]);
end

% file size
fseek(fg_fh, 0, 'eof');
fsize = ftell(fg_fh);
fseek(fg_fh, 0, 'bof');

% fg files seem to have a magic cookie: FRFG0001 (the fifth or sixth char of which
% might indicate encryption)
fg_struct.FAN_FG_FILE_ID = 'FRFG0001';		% taken from FanFgFile.cpp
fg_struct.FAN_FG_SCALE = 1000.0;				% taken from FanFgFile.cpp
fg_struct.scale_factor = 1.0 / fg_struct.FAN_FG_SCALE;	% taken from FanFgFile.cpp

% read the header
fg_struct.magic_cookie = fread(fg_fh, [1, 8], 'uint8=>char');	% TODO compare the encryption position...
% the next set is all unsigned long on 
fg_struct.egmKey = fread(fg_fh, 1, 'uint32=>uint32');	%
fg_struct.egtKey = fread(fg_fh, 1, 'uint32=>uint32');	%
fg_struct.numGs = fread(fg_fh, 1, 'uint32=>uint32');	% number of symmetric geometry values
fg_struct.numGa = fread(fg_fh, 1, 'uint32=>uint32');	% number of asymmetric geometry values
fg_struct.numTs = fread(fg_fh, 1, 'uint32=>uint32');	% number of symmetric texture values
fg_struct.numTa = fread(fg_fh, 1, 'uint32=>uint32');	% number of asymmetric texture values
fg_struct.numResiduals = fread(fg_fh, 1, 'uint32=>uint32');	% this should be ZERO
fg_struct.detailTexture = fread(fg_fh, 1, 'uint32=>uint32');	%

% read the face coordinates
% FG wants the values as floats but stores them as shorts, take care of
% this during loading
if (fg_struct.numGs),
	fg_struct.coordGs_short = fread(fg_fh, [1, double(fg_struct.numGs)], 'int16=>int16');	%
	fg_struct.coordGs = single(double(fg_struct.coordGs_short) * fg_struct.scale_factor);
end
if (fg_struct.numGa),
	fg_struct.coordGa_short = fread(fg_fh, [1, double(fg_struct.numGa)], 'int16=>int16');	%
	fg_struct.coordGa = single(double(fg_struct.coordGa_short) * fg_struct.scale_factor);
end
if (fg_struct.numTs),
	fg_struct.coordTs_short = fread(fg_fh, [1, double(fg_struct.numTs)], 'int16=>int16');	%
	fg_struct.coordTs = single(double(fg_struct.coordTs_short) * fg_struct.scale_factor);
end
if (fg_struct.numTa),
	fg_struct.coordTa_short = fread(fg_fh, [1, double(fg_struct.numTa)], 'int16=>int16');	%
	fg_struct.coordTa = single(double(fg_struct.coordTa_short) * fg_struct.scale_factor);
end

% if there is a detail texture load it as well
if (fg_struct.detailTexture),
	fg_struct.num_char_detailTexJpeg = fread(fg_fh, 1, 'uint32=>int32');	%JPEG buffer size
	fg_struct.detailTexJpeg = fread(fg_fh, [1, double(fg_struct.num_char_detailTexJpeg)], 'uint8=>uint8'); %
end




% clean up
fclose(fg_fh);

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [out] = cluster_fgs(fgvalues_by_ID_array, names_list, n_cluster, dist_type, link_type, debug)
% taylor this to extract the n_cluster most distinctive input IDs

% create the dissimilarity matrices
dissimilarities = pdist(fgvalues_by_ID_array', dist_type);
out.dissimilarities = dissimilarities;

% show the dissimilarity map
cluster_fig_h = figure('Name', 'cluster info');
dm_h = subplot(2, 2, 1);
out.tmp_distance_img = squareform(dissimilarities);
imagesc(out.tmp_distance_img);
axis equal
xlabel('IDs');
ylabel('IDs');

tmp_linkage = linkage(dissimilarities, link_type);
out.tmp_linkage = tmp_linkage;

dg_h = subplot(2, 2, 2);
[out.dendrogram_H, out.dendrogram_T, out.dendrogram_perm] = dendrogram(tmp_linkage, n_cluster, 'colorthreshold', 'default', 'labels', names_list);
xlabel('IDs');
ylabel('Distance');

mds_nm_h = subplot(2, 2, 3);
% Use non-metric scaling to recreate the data in 2D,
% and make a Shepard plot of the results.
opts = statset('Display', 'final');
[Y, stress, disparities] = mdscale(dissimilarities, 2, 'Criterion', 'sstress', 'Start', 'cmdscale', 'Replicates', 2, 'Options', opts);
distances = pdist(Y);
[dum, ord] = sortrows([disparities(:) dissimilarities(:)]);
plot(dissimilarities, distances,'bo', dissimilarities(ord), disparities(ord), 'r.-');
xlabel('Dissimilarities'); 
ylabel('Distances/Disparities');
legend({'Distances' 'Disparities'}, 'Location', 'NW');

mds_m_h = subplot(2, 2, 4);
% Do metric scaling on the same dissimilarities.
[Y, stress] = mdscale(dissimilarities, 2, 'criterion', 'metricsstress');
distances = pdist(Y);
plot(dissimilarities, distances, 'bo', [0 max(dissimilarities)], [0 max(dissimilarities)], 'k:');
xlabel('Dissimilarities');
ylabel('Distances');


out.cluster_T = cluster(tmp_linkage, 'maxclust', n_cluster);

% both cluster and dendrogram give similar clusterfication
% compare
% figure; plot(T, (1:433), ID_2_cluster_relation, (1:433));


return


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [cluster_center_ID_list] = find_fg_closest_2_cluster_mean(fgvalues_by_ID_array, fg_names, fg_2_cluster_relation)
% now pick one cluster method and find for each cluster the fg closest to
% the cluster mean


cluster_list = sort(unique(fg_2_cluster_relation));
n_cluster = length(cluster_list);
mean_fgvals_in_cluster = zeros(size(fgvalues_by_ID_array, 1), n_cluster);
cluster_center_ID_list = cell([1, n_cluster]);

for i_cluster = 1:n_cluster
	cluster_num = cluster_list(i_cluster);
	fg_in_cluster_idx = find(fg_2_cluster_relation == cluster_num);
	if ~isempty(fg_in_cluster_idx),
		n_fg_in_cluster = length(fg_in_cluster_idx);
		fg_names_in_cluster = fg_names(fg_in_cluster_idx);
		% get a vector describing the 'center' of the cluster
		mean_fgvals_in_cluster(:, i_cluster) = mean(fgvalues_by_ID_array(:, fg_in_cluster_idx), 2);
		% just prepare a small matrix with all fg in this cluster plus the
		% cluster_mean tacked on at the end
		cluster_fg = [fgvalues_by_ID_array(:, fg_in_cluster_idx) mean_fgvals_in_cluster(:, i_cluster)];
		% now find the fg closest to the cluster mean
		distances = pdist(cluster_fg', 'euclidean');
		distances_square = squareform(distances);
		[tmp_min, min_idx] = min(distances_square(n_fg_in_cluster + 1, 1:end - 1));	% min_idx points to the fg closest to the cluster center
		cluster_center_ID_list{i_cluster} = fg_names_in_cluster{min_idx};
	end	
end


return

