function facegen_2_imagelooper_02(figure_files, output_dir)
% turn face gen models into images, allow to specify pose, expression value
% lists to iterate over (create poses*expressions number of images per
% faegen model)
% the actual call to fg3 generate is rather slow!
% TODO
%
% DONE

timestamps.(mfilename).start = tic;
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');
mfilepath = fileparts(fq_mfilename);

% %%%%% control vars
save_code = 1;		% make a timestamped xzip archive of the code directory in the target directory
run_fg3 = 1;		% really run the fg3 command (process_img is a suboption of this)
copy_fgs = 1;		% copy the source fg models to the data directory (for documentation purposes)
process_img = 1;	% this way only processed images are stored in the output directory
% crop the output images, say to keep them square, will crop around
% centerpoint
crop_img = 1;
crop_width = 480;
crop_height = 480;

% scale image to width im pixel, height gets adjusted to keep the aspect
% ratio, done after cropping
scale_img = 1;
scale_img_2_width = 400;
scale_img_2_height = 0;		% leave at zero for keeping the aspect ratio

% the models come with slightly differing background intesities so fix this
% up, initially just plain dumb
replace_bg = 1;
bg_type = 'BACKGROUND_COLOUR';	% BACKGROUND_COLOUR for the initialy specified bg color or IMAGE
bg_img_file = fullfile('path', 'to', 'background.img');	% if bg_type is IMAGE this will be loaded
bg_fuzz = 10;	% fuzzyness of bg search, 10 seems okay on first approximation

% change image into grayscale
convert_2_grayscale = 0;


debug = 0;
% StimulusSet_id = ['FG_ID_morphs_', '01'];	% 
% set_suffix = '_07ratios';

StimulusSet_id = ['FG_ID_morphs_', '02'];	% 
set_suffix = '_08ratios';

% ready this for unix systems...
[sys_status, host_name] = system('hostname');
switch host_name(1:end-1) % last char of host name result is ascii 10 (LF)
	case 'virt764'
		% virtual windows 7 64 bit under vbox on mac
		FIGURE_FILE_DIR = fullfile('H:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs', ['tweened', set_suffix]);
		OUTPUT_DIR = fullfile('H:', 'space', 'data', 'moeller', 'face_project', 'KOFIKO', 'StimulusSet', StimulusSet_id, 'images');
	case 'janus'
		FIGURE_FILE_DIR = fullfile('C:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs', ['tweened', set_suffix]);
		OUTPUT_DIR = fullfile('C:', 'space', 'data', 'moeller', 'face_project', 'KOFIKO', 'StimulusSet', StimulusSet_id, 'images');
	%case 'KOFIKO-USER-23A'
	%case 'hms-beagle'
	otherwise
		error(['Hostname ', host_name(1:end-1), ' not handeled yet']);
end

%OUTPUT_DIR = fullfile(FIGURE_FILE_DIR, 'images');
fg_out_dir = fullfile(OUTPUT_DIR, '..', 'morphed_FGs');

figure_file_list = [];	% keep empty to read in all modells from FIGURE_FILE_DIR

% simple rf3 style list of images
write_imglist = 1;				% simple textfile each image name per row
imglist_fqn = fullfile(OUTPUT_DIR, ['_imglist', '.txt']);
img_prefix_dir = [];		% if specified prefix this directory name to each row in the imglist_fqn

xml_media_section.write = 1;	% kofiko 2 stye media section
xml_media_section.kofiko_system = 'KOFIKO-USER-23A';
xml_media_section.abs_img_path_4_kofiko = ['\\', xml_media_section.kofiko_system, '\', 'StimulusSet', '\', [StimulusSet_id, ''], '\', 'images'];	% force backslashes so it can run on unices
xml_media_section.main_exp_name_string = 'morphs_01';	% just a convenient way to include an arbitrary attribute for the whole list
xml_media_section.common_attributes_string = 'morphs_01;familiar;human;face';	% just a convenient way to include an arbitrary attribute for the whole list
xml_media_section.version_string = 'v01';
xml_media_section.xml_fqn = fullfile(OUTPUT_DIR, '..', ['kofiko_v2_xml_media_section_', StimulusSet_id, '_', ...
	xml_media_section.main_exp_name_string, '_', ...
	xml_media_section.version_string, '.txt']);


%  assume to find a list of file names without pathes
if ~isempty(figure_file_list),
	fid = fopen(fullfile(FIGURE_FILE_DIR, figure_file_list), 'r');
	tmp_figure_files = textscan(fid, '%s');
	figure_files = sort(tmp_figure_files{1}');
	fclose(fid);
end

% define the default values for fg3 generate
fg3_struct.generate = fg3_define_generate_arguments('default_set');

% Data paths
fg3_struct.dirs = fg3_define_dirs;


% to generate different expressions or orientations seed the following:
EXPRESSION_list = {fg3_struct.generate.EXPRESSION};	% None, Anger, Disgust, Fear, Sad, Smile_Closed, Smile_Open, or Surprise
% to define a pose give AZI and corresponding ELE in the following lists
POSE_AZIMUTH_list = {-45 0 45};	% fg3_struct.POSE_AZIMUTH
POSE_ELEVATION_list = {fg3_struct.generate.POSE_ELEVATION fg3_struct.generate.POSE_ELEVATION fg3_struct.generate.POSE_ELEVATION};	% fg3_struct.POSE_ELEVATION

% Allows specification of paths relative to this file
[parent_dir, mfile_name, mfile_ext] = fileparts(mfilename('fullpath'));
%cd(parent_dir);

% if no figure files specified, use FIGURE_FILE_DIR
if (~exist('figure_files', 'var'))
	dir_output = dir(fullfile(FIGURE_FILE_DIR, '*.fg'));	% only bother with actual fg files
	figure_files = {};
	for i=1:length(dir_output)
		% skip parent directory and other hidden files
		if (dir_output(i).name(1) ~= '.')
			figure_files{end + 1} = fullfile(FIGURE_FILE_DIR, dir_output(i).name);
		end
	end
else
	for i=1:length(figure_files)
		figure_files{i} = fullfile(FIGURE_FILE_DIR, figure_files{i});
	end
end
if isempty(figure_files)
	disp('No facegen models found, exiting...');
end
% If no output directory specified, use OUTPUT_DIR
if (~exist('output_dir', 'var'))
	output_dir = OUTPUT_DIR;
end
% Create output directory if it does not exist
if (~exist(output_dir, 'file'))
	mkdir(output_dir);
end
if (~exist(fg_out_dir, 'file'))
	mkdir(fg_out_dir);
end


% list of images
img_name_list = cell([1 (length(figure_files) * length(EXPRESSION_list) * length(POSE_AZIMUTH_list))]);
img_counter = 0;

% Generate faces
for i_fg=1:length(figure_files)
	[figure_pathstr, figure_name, figure_ext] = fileparts(figure_files{i_fg});
	figure_base_name = ['ID_', figure_name];

	if (copy_fgs)
		copyfile(figure_files{i_fg}, fullfile(fg_out_dir, [figure_name, '.' ,figure_ext]));
	end

	% allow looping over different parameters
	for i_expression = 1 : length(EXPRESSION_list)
		fg3_struct.generate.EXPRESSION = EXPRESSION_list{i_expression};
		figure_exp_name = [figure_base_name, '-', 'EXP_', fg3_struct.generate.EXPRESSION];
		for i_ori = 1 : length(POSE_AZIMUTH_list)
			fg3_struct.generate.POSE_AZIMUTH = POSE_AZIMUTH_list{i_ori};
			fg3_struct.generate.POSE_ELEVATION = POSE_ELEVATION_list{i_ori};
			figure_name = [figure_exp_name, '-', 'ORI_', 'A', num2str(fg3_struct.generate.POSE_AZIMUTH, '%03d'), '_', 'E', num2str(fg3_struct.generate.POSE_ELEVATION, '%03d')];
			disp(['Processing: ', figure_files{i_fg}, ', output: ', figure_name]);
			img_counter = img_counter + 1;
			img_name_list{img_counter} = [figure_name, '.jpg'];
			if (run_fg3)
				[status, result] = fg3('generate', fg3_struct, figure_files{i_fg});
				%disp(['fg3 generate status: ', status']);
				if (status ~= 0),
					disp(result);
				end
				if(fg3_struct.generate.SAVE_DATAFILES)
					copyfile(fullfile(fg3_struct.dirs.TMP_DIR, '000000_1.txt'), fullfile(output_dir, [figure_name, '.txt']));
				end

				if (process_img),
					% read in the image
					img = imread(fullfile(fg3_struct.dirs.TMP_DIR, '000000_1.jpg'));
					% TODO force RGB type if grayscale
					if (size(img, 3) == 1),
						%TODO fix me up TEST ME, basically do reverse rgb2gray here single plane?  we found a gray scale image
						tmp_img = gray2ind(img, 256);
						img = ind2rgb(tmp_img);
						convert_2_grayscale = 1;
					end

					if (replace_bg),
						img = replace_img_bg(img, bg_type, bg_img_file, fg3_struct.generate.BACKGROUND_COLOUR, bg_fuzz, debug);
						if (debug),
							imagesc(img);
						end
					end

					%TODO squash bg color for gray scale images
					bg_color = reshape(uint8(fg3_struct.generate.BACKGROUND_COLOUR), [1 1 3]);	% 8bit RGB
					if (debug),
						bg_color = reshape(uint8([255 0 0]), [1 1 3]) ;	% 8bit FULL RED
					end

					if (crop_img),
						img = crop_image(img, crop_height, crop_width, bg_color, debug);
					end %crop

					if (convert_2_grayscale),
						img = rgb2gray(img);
					end

					% rescale images
					if (scale_img),
						img = scale_image(img, scale_img_2_height, scale_img_2_width);
					end

					% write out img
					imwrite(img, fullfile(output_dir, [figure_name, '.jpg']), 'jpg', 'Quality', 100);

				else
					% stick to the image generated by fg3
					copyfile(fullfile(fg3_struct.dirs.TMP_DIR, '000000_1.jpg'), fullfile(output_dir, [figure_name, '.jpg']));
				end % process_images
			end % run_fg3
		end
	end

end		% end of for loop

if (write_imglist),
	write_simple_imglist(imglist_fqn, img_name_list, img_prefix_dir);
end


if (xml_media_section.write),
	write_xml_media_section(img_name_list, xml_media_section.xml_fqn, xml_media_section);
end

% saving the code that generated the outpput into the output directory...
if (save_code)
	disp('Saving all matlab code that generated the outputs into the output directory');
	mfile_fqn = mfilename('fullpath');
	code_dir = fileparts(mfile_fqn);
	% save the code in a versioned directory...
	%gzip(code_dir, fullfile(dirs.out_img_lists, [mfilename, '_',
	%datestr(clock, 30)]));	% this compressed each file individually
	zip(fullfile(OUTPUT_DIR, [mfilename, '_', datestr(clock, 30), '.zip']), code_dir); % compresses all files into one archive
end


timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds. Done...']);
return
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function str = arg_range(number)
if(length(number) == 2)
	str = [number(1) ',' number(2)];
else
	str = num2str(number);
	str = [str ',' str];
end
return
end




% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [img] = scale_image(in_img, scale_img_2_height, scale_img_2_width)
% scale_image scale image to the size given by scale_img_2_height and
% scale_img_2_width, if one is set to zero, maintain aspect ratio of this
% dimension while scaleing

% only rescale if the width actually changes...
% zero means: keep aspect ratio
if ~((scale_img_2_width == 0) && (scale_img_2_height == 0)),
	if (scale_img_2_width > 0) && (scale_img_2_height == 0),
		% scale to new width while keeping aspect ratio
		img = imresize(in_img, [NaN scale_img_2_width], 'bicubic');
	elseif (scale_img_2_width == 0) && (scale_img_2_height > 0),
		% scale to new height while keeping aspect ratio
		img = imresize(in_img, [scale_img_2_height NaN], 'bicubic');
	elseif (scale_img_2_width > 0) && (scale_img_2_height > 0),
		% scale to new height and new width, potentially
		% stretching or compressing the image
		img = imresize(in_img, [scale_img_2_height scale_img_2_width], 'bicubic');
	end
end
return
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function img = crop_image(img, crop_height, crop_width, bg_color, debug)
% crop or extend the image canvas, centered; extensions will be of bg_color
% crop image or extend the canvas, relative to center, this will
% if the finalsize is not an even number of pixels smaller or
% larger than the input, the cropping will be shifted one pixel
% from the center, therefore the center error gets larger as
% the final image size gets smaller
%TODO: test with grayscale images...

img_size = size(img);	% [height widths depth]
cur_height = img_size(1);
cur_width = img_size(2);
if ~((crop_height == img_size(1)) && (crop_width == img_size(2))),	% only crop if necessary
	if (debug),
		if (crop_height > img_size(1)),
			disp('Requested crop height larger than image, padding image...');
		else
			if (crop_height < img_size(1)),
				disp('Cropping height of image');
			end
		end
		if (crop_width > img_size(2)),
			disp('Requested crop width larger than image, padding image...');
		else
			if (crop_width < img_size(1)),
				disp('Cropping width of image');
			end
		end
	end
	height_delta = crop_height - cur_height;
	d_h_U = floor(height_delta / 2);	% due to floor we might miss one row
	d_h_D = ceil(height_delta / 2);	% due to floor we might miss one row

	width_delta = crop_width - cur_width;
	d_h_R = floor(width_delta / 2);	% due to floor we might miss one row
	d_h_L = ceil(width_delta / 2);	% due to floor we might miss one row


	tmp_img = repmat(bg_color, [crop_height crop_width 1]);
	% now copy in the original image
	tmp_img(max([d_h_U 0]) + 1: d_h_U + cur_height + min([d_h_D 0]), max([d_h_L 0]) + 1: d_h_L + cur_width + min([d_h_R 0]), :) = ...
		img(abs(min([d_h_U 0])) + 1 : cur_height + min([d_h_D 0]),...
		abs(min([d_h_L 0])) + 1 : cur_width + min([d_h_R 0]),...
		:);
	img = tmp_img;
	if (debug),
		imagesc(img);
	end
end

return
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rf3_img = conform_img_2_rf3_colorspace(img, rf3_color_palette)
% map the image to the given RF3 colo palette
% initially use heuristics, best would be to actually use the color maps
% with rgb2ind
% TODO check number of planes, just assume RGB for now

switch (rf3_color_palette)
	case 'palnew'
		% all gays
		rf3_img = rgb2gray(img);
	case 'palgray'
		% all grays
		rf3_img = rgb2gray(img);
	case 'palgray32'
		img = rgb2gray(img);
		% some reserved
		n_res_col = 35;	% number of reserved colors somewhere between 32 and 40
		% only process images which use the lower n_res_col indices (0 to n_res_col - 1)
		if (min(min(img)) < n_res_col),
			%disp(['Processing: ', name]);
			img_adj = double(img);
			for color = 0:255,
				col_idx = find(img == color);
				if ~isempty(col_idx),
					% already scaled color values are negated to move them out of
					% the way, this is stupid but works...
					img_adj(col_idx) = ((color  * 255 / (255 + n_res_col)) + n_res_col) * (-1);
				end
			end
			% now make the image positive again...
			rf3_img = uint8(round(img_adj * (-1)));
		else
			rf3_img = img;
		end
	case 'palrf3_p_'
		% TODO get real colormap
	otherwise
		disp(['Unknown RF3 palette: ', rf3_color_palette]);
		disp('No colormapping performed...');
end
return
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [img] = replace_img_bg(in_img, bg_type, bg_img_file, bg_color, bg_fuzz, debug)
% replace the image background with bg_img, if bg_type = 'BACKGROUND_COLOUR'
% create a flat file
% it might be a good idea to use region growing code for that...

img = in_img;
%first segment bg from img, assume img(1,1) contains no face pixel)
img_size = size(img);
proto_bg_col = squeeze(img(1, 1, :));
tmp_proto_bg_img = repmat(reshape(proto_bg_col, [1, 1, 3]), [img_size(1) img_size(2) 1]);
tmp_bg_img = repmat(reshape(bg_color, [1, 1, 3]), [img_size(1) img_size(2) 1]);

% this works but needs a little fuzzyness
tmp_proto_bg_pixel_list = find((img(:, :, 1) == proto_bg_col(1)) & (img(:, :, 2) == proto_bg_col(2)) & (img(:, :, 3) == proto_bg_col(3)));
% fuzzy it is then, casts to double are necessary otherwise pixels with img
% < bg_color are taken as bg, which is more fuzzy then wished for
tmp_img = abs((double(img) - double(tmp_proto_bg_img)));
proto_bg_pixel_list = find(	(tmp_img(:, :, 1) <= bg_fuzz + eps) & ...
	(tmp_img(:, :, 2) <= bg_fuzz + eps) & ...
	(tmp_img(:, :, 3) <= bg_fuzz + eps));

switch bg_type
	case 'BACKGROUND_COLOUR'
		if (debug),
			bg_color = [255 0 0];
		end
		tmp_bg_img = repmat(reshape(bg_color, [1, 1, 3]), [img_size(1) img_size(2) 1]);
		img(proto_bg_pixel_list) = tmp_bg_img(proto_bg_pixel_list);
	case 'IMAGE'
		bg_img = imread(bg_img_file);
		% TODO test if size(bg_img) ~= size(img)
		bg_img_size = size(bg_img);
		if (~isequal(img_size, bg_img_size)),
			img(proto_bg_pixel_list) = bg_img(proto_bg_pixel_list);
		else
			error('Specified background image is of different size than foreground image, and that is not yet handled, aborting...');
		end
	otherwise
		error(['Unknown bg_type (', bg_type, ') specified, aborting...']);
end

return
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ ] = write_simple_imglist(list_fqn, img_name_list, img_prefix_dir)

if (nargin < 3)
	img_prefix_dir = [];
end

[list_dir, list_name] = fileparts(list_fqn);
% open imagelists

imglist_fd = fopen(fullfile(list_dir, [list_name, '.txt']), 'w');
if (imglist_fd == -1),
	error('Could not create imglist, something is fishy...');
end

% write entries in image lists:
for i_img = 1 : length(img_name_list)
	if isempty(img_prefix_dir)
		fprintf(imglist_fd, '%s\n', img_name_list{i_img});
	else
		fprintf(imglist_fd, '%s\n', fullfile(img_prefix_dir, img_name_list{i_img}));
	end
end

disp('Closing imglist...');
fclose(imglist_fd);

return
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ ] = write_xml_media_section(img_name_list, xml_list_fqn, xml_media_section)

% now write the media section to the file
fcd_fh = fopen(xml_list_fqn, 'w+');
if (fcd_fh == -1)
	error(['Could not open ', xml_list_fqn, ' for writing, aborting...']);
end

% xml section start
fprintf(fcd_fh, ' <Media>\r\n');

% TODO include the masking level as attribute
for i_img = 1 : length(img_name_list)
	% <Image Name = "face1-0" FileName =
	%  "\\KOFIKO-USER-23A\StimulusSet\AM_familiarity_02\face1_0.jpg" Attr =
	%  "IdentityMatching_Exp1;Face1"> </Image>
	cur_img = img_name_list{i_img};
	[dummy, cur_img_name, cur_img_ext] = fileparts(cur_img);
	attribute_string = [xml_media_section.common_attributes_string, extract_attributes_from_img_name([cur_img_name, cur_img_ext])];	% extract_attributes_from_img_name has leading ';'
	fprintf(fcd_fh, ' <Image Name = \"%s\" FileName = \"%s\" Attr = \"%s\"> </Image>\r\n', ...
		cur_img_name, ...
		[xml_media_section.abs_img_path_4_kofiko, '\', cur_img], ...
		attribute_string);
end

% xml section stop
fprintf(fcd_fh, ' </Media>\r\n');
% clean-up
fclose(fcd_fh);

xml_media_section.main_exp_name_string = 'morphs_01';	% jus

return
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [attrib_string] = extract_attributes_from_img_name(cur_img_name)
% example: 'human;face;tweened_050.1pct'
% extract the properties from the image name
img_properties = parse_img_name_v02(cur_img_name);

attrib_string_type = 'short';
% construct the attribute string to return
attrib_string = '';
switch attrib_string_type
	case 'full'
		% ID
		attrib_string = [attrib_string, ';', ['ID.', img_properties.attr.ID.identity]];
		if isfield(img_properties.attr.ID, 'tweenedID1')
			attrib_string = [attrib_string, ';', ['ID_SRC1.',img_properties.attr.ID.tweenedID1.identity]];
		end
		if isfield(img_properties.attr.ID, 'tweenedID2')
			attrib_string = [attrib_string, ';', ['ID_SRC2.',img_properties.attr.ID.tweenedID2.identity]];
		end
		% ORI
		if isfield(img_properties.attr.ORI, 'string')
			attrib_string = [attrib_string, ';', ['ORI.', img_properties.attr.ORI.string]];
		end
		% TRF
		if isfield(img_properties.attr.TRF, 'string')
			attrib_string = [attrib_string, ';', ['TRF.', img_properties.attr.TRF.string]];
		end

		% EXP
		% BG
	case 'short'
		% minimal set to fit kofiko2 cue selection primitives
		% ID
		%attrib_string = [attrib_string, ';', ['ID.', img_properties.attr.ID.identity]];
		if isfield(img_properties.attr.ID, 'tweenedID1') & isfield(img_properties.attr.ID, 'tweenedID1') & isfield(img_properties.attr, 'TRF')
			if isfield(img_properties.attr.TRF, 'tweened')
				if (img_properties.attr.TRF.tweened.tweened_pct >= 50.0)
					dominant_ID = img_properties.attr.ID.tweenedID1.identity;
					dom_ID_pct = img_properties.attr.TRF.tweened.tweened_pct;
				else
					dominant_ID = img_properties.attr.ID.tweenedID2.identity;
					dom_ID_pct = 100 - img_properties.attr.TRF.tweened.tweened_pct;

				end
				attrib_string = [attrib_string, ';', ['dominantID.', dominant_ID], ';', ['domIDpct.', num2str(dom_ID_pct, '%05.1f')]];
				%prop_struct_attr_TRF.tweened.tweened_pct
			end

		end
	otherwise
end
return
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

