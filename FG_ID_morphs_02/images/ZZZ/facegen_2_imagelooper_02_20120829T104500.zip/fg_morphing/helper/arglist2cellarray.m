function [ out_list ] = arglist2cellarray( varargin )
%ARGLIST@ARRAY take a list of arguments as cell array and convert
%   Detailed explanation goes here

out_list = cell([1, nargin]);
for i_cell = 1 : nargin
	out_list{i_cell} = varargin{i_cell};
end

return
end

