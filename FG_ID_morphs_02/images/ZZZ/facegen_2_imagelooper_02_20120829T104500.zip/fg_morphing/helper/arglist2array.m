function [ out_list ] = arglist2array( varargin )
%ARGLIST@ARRAY take a list of arguments as cell array and convert
%   Detailed explanation goes here

out_list = zeros([1, nargin]);
for i_cell = 1 : nargin
	out_list(i_cell) = varargin{i_cell};
end

return
end

