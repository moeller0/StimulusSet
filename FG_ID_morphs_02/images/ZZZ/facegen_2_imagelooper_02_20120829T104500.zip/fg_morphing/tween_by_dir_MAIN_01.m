function [ output_args ] = tween_by_dir_MAIN( input_args )
%TWEEN_TESTER Summary of this function goes here
%   Detailed explanation goes here
timestamps.(mfilename).start = tic;
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');
mfilepath = fileparts(fq_mfilename);


save_code = 1;
src_dir = fullfile('H:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs');
out_dir = fullfile(src_dir, 'tweened');

fg_morpher(src_dir, out_dir, [0.0000, 0.1667, 0.3333, 0.4500, 0.5500, 0.6667, 0.8333, 1.0000]);
%fg_morpher(src_dir, out_dir, [0.0]);


% saving the code that generated the outpput into the output directory...
if (save_code)
	disp('Saving all matlab code that generated the outputs into the output directory');
	mfile_fqn = mfilename('fullpath');
	code_dir = fileparts(mfile_fqn);
	% save the code in a versioned directory...
	%gzip(code_dir, fullfile(dirs.out_img_lists, [mfilename, '_',
	%datestr(clock, 30)]));	% this compressed each file individually
	zip(fullfile(out_dir, [mfilename, '_', datestr(clock, 30), '.zip']), code_dir); % compresses all files into one archive
end

timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds. Done...']);
return
end