function [ fg3_dirs ] = fg3_define_dirs( )
%FG3_DEFINE_DIRS define where to find the facegen SDK and the required
%components
%   Detailed explanation goes here
fg3_dirs.TMP_DIR = getenv('TEMP');
fg3_dirs.FG3_BIN = fullfile('..', 'Fg3FullSDK.3.6.0_sm', 'bin', 'VisualStudio2008', 'x64', 'Debug', 'fg3.exe');
fg3_dirs.CTL_FILE = fullfile('..', 'Fg3FullSDK.3.6.0_sm', 'data', 'fg3', 'sdk', 'si.ctl');
fg3_dirs.data = fullfile('..', 'Fg3FullSDK.3.6.0_sm', 'data', 'fg3', 'sdk');	% internal
% SAM_PATH = 'lib\csam1000poly\1000Face.*';	% just the face
% SAM_PATH = 'lib\csam1000poly\1000Face.*, --sam_model=lib\csam1000poly\1000Head.*, --sam_model=lib\csam1000poly\1000TTS.*';	%just the face
% full head
% --sam_model=[VALUE]  % Comma separated list of files for SAM model (TRI,EGM,BMP,EGT,FIM,OVI,OVA). Multiple arguments allowed. --sam_model=foo.* implies all SAM files. Overlays are specified using OVI/OVA files. To specify multiple overlays, simply specify multiple OVI and OVA files. Required argument.
fg3_dirs.SAM_PATH = [fg3_dirs.data, '\csamDefault\skin_hi.*, --sam_model=', ...
                    fg3_dirs.data, '\csamDefault\eyeL_hi.*, --sam_model=', ...
                    fg3_dirs.data, '\csamDefault\eyeR_hi.*, --sam_model=', ...
                    fg3_dirs.data, '\csamDefault\teethUpper.*, --sam_model=', ...
                    fg3_dirs.data, '\csamDefault\teethLower.*, --sam_model=', ...
                    fg3_dirs.data, '\csamDefault\tongue.*, --sam_model=', ...
                    fg3_dirs.data, '\csamDefault\sock.*'];
fg3_dirs.DETAIL_TEXTURES_PATH = [fg3_dirs.data, '\detailTextures'];	%Directory from which to choose detail textu Defaults to detailTextures.

return
end