function facegen_morpher_01(figure_files, output_dir)
% Figure and output directories
% Ignored if arguments are specified

% TODO
%	create/read in lists of src and targ facegen models and create a number
%	of intermediate tweens between all defined pairs
%
% DONE


% %%%%% control vars
process_img = 1;	% this way only processed images are stored in the output directory

% crop the output images, say to keep the square, will crop around
% centerpoint
crop_img = 1;
crop_width = 480;
crop_height = 480;

% scale image to width im pixel, height gets adjusted to keep the aspect
% ratio, done after cropping
scale_img = 1;
scale_img_2_width = 256;
scale_img_2_height = 0;		% leave at zero for keeping the aspect ratio

% the models come with slifgtly differing background ntesities so fix this
% up, initially just plain dumb
replace_bg = 1;
bg_type = 'BACKGROUND_COLOUR';	% BACKGROUND_COLOUR for the initialy specified bg color or IMAGE
bg_img_file = fullfile('path', 'to', 'background.img');	% if bg_type is IMAGE this will be loaded
bg_fuzz = 10;	% fuzzyness of bg search, 10 seems okay on first attempt

% change image into grayscale
convert_2_grayscale = 0;
write_imglist = 1;
imglist_name = '_imglist_50-IDs_at_3ORIs_and_50-OBJs_01';

rf3_square_size = 256;


test = 0;	% single test image or the whole works
debug = 0;

% %%% SIMONS WORK
if (test),
	FIGURE_FILE_DIR = fullfile('lib', 'test');
	OUTPUT_DIR = fullfile('', 'test_out');
else
% 	FIGURE_FILE_DIR = fullfile('lib', 'IDs');
% 	FIGURE_FILE_DIR = fullfile('lib', 'good_models');
	FIGURE_FILE_DIR = fullfile('', 'IDs');
	OUTPUT_DIR = fullfile('', 'AM_localizer_01');
	figure_file_list = 'distinctest_50_fg_names.txt';	% keep empty to read in all modells from FIGURE_FILE_DIR
end

%  assume to find a list of file names without pathes
if ~isempty(figure_file_list),
	fid = fopen(fullfile(FIGURE_FILE_DIR, figure_file_list), 'r');
	tmp_figure_files = textscan(fid, '%s');
	figure_files = sort(tmp_figure_files{1}');
	fclose(fid);
end


% Facial expression. This is one of None, Anger, Disgust, Fear, Sad,
% Smile_Closed, Smile_Open, or Surprise
% all leaf values passed to fg3 in CAPS
fg3.generate.EXPRESSION = 'None';				% None, Anger, Disgust, Fear, Sad, Smile_Closed, Smile_Open, or Surprise
fg3.generate.IMAGE_SIZE = [640 480];
fg3.generate.LOG_LEVEL = 0;						% 0 = Most, 4 = None   Defaults to 1.
fg3.generate.NUMBER_PIXELS_BETWEEN_EYES = 118;	% Number of pixels between eyes of mean face. Each rendered face uses this as a basis. Defaults to 128.
fg3.generate.BACKGROUND_COLOUR = [128 128 128];	% Comma-separated RGB values (R,G,B) to use for background colour. Values range from 0-255 Defaults to 0,0,0.
fg3.generate.AMBIENT_BRIGHTNESS = 0.25;
fg3.generate.BLINK_COEFFICIENT = 0;
fg3.generate.DISTANCE = 3;
fg3.generate.EXPRESSION_COEFFICIENT = 1;			% Expression coefficient (level) range Defaults to 0,0.5.
fg3.generate.GAMMA = 2.2;						% Gamma range Defaults to 1.5,2.5.
fg3.generate.HEAD_TILT = 0;						% Head tilt range. Defaults to -10,10.
fg3.generate.LIGHT1_AZIMUTH = 0;
fg3.generate.LIGHT1_BRIGHTNESS = 0.5;
fg3.generate.LIGHT1_ELEVATION = 0.2;
fg3.generate.LIGHT2_AZIMUTH = 10;
fg3.generate.LIGHT2_BRIGHTNESS = 0.5;
fg3.generate.LIGHT2_ELEVATION = 0.15;
fg3.generate.LIGHT3_AZIMUTH = -10;
fg3.generate.LIGHT3_BRIGHTNESS = 0.5;
fg3.generate.LIGHT3_ELEVATION = 0.15;
fg3.generate.POSE_AZIMUTH = 0;			% Pose Azimuth range   Defaults to -45,45.
fg3.generate.POSE_ELEVATION = 10;		% Pose elevation range Defaults to 0,20.
fg3.generate.TEXTURE_MODULATION = 1;		% Texture modulation range Defaults to 1,1.5.
fg3.generate.SAVE_DATAFILES = 1;			% Whether to save data files or not. A datafile consists of the physical parameters used to generate an image. Defaults to 1.
fg3.generate.SEED = 12345;				% Seed for the random number generator. If set to 0, a seed based on the current time is chosen. Defaults to 0.
fg3.generate.SHRINK_FACTOR = 1;			% Anti-aliasing image shrink factor. Defaults to 1.
fg3.generate.MUGSHOT = 1;				% Whether or not render a mugshot image. Defaults to 1. (only mugshots use model texture) ALWAYS set to one
fg3.generate.N_POSES = 1;
fg3.generate.N_FACES = 1;
fg3.generate.AVG_FACE = 0;
fg3.generate.FROM = 0;

% Data paths
fg3.dirs = fg3_define_dirs;

% fg3.dirs.TMP_DIR = getenv('TEMP');
% fg3.dirs.FG3_BIN = fullfile('Fg3FullSDK.3.6.0', 'bin', 'VisualStudio2008', 'x64', 'Debug', 'fg3.exe');
% fg3.dirs.CTL_FILE = fullfile('Fg3FullSDK.3.6.0', 'data', 'fg3', 'sdk', 'si.ctl');
% fg3.dirs.data = fullfile('Fg3FullSDK.3.6.0', 'data', 'fg3', 'sdk');	% internal
% % SAM_PATH = 'lib\csam1000poly\1000Face.*';	% just the face
% % SAM_PATH = 'lib\csam1000poly\1000Face.*, --sam_model=lib\csam1000poly\1000Head.*, --sam_model=lib\csam1000poly\1000TTS.*';	%just the face
% % full head
% % --sam_model=[VALUE]  % Comma separated list of files for SAM model (TRI,EGM,BMP,EGT,FIM,OVI,OVA). Multiple arguments allowed. --sam_model=foo.* implies all SAM files. Overlays are specified using OVI/OVA files. To specify multiple overlays, simply specify multiple OVI and OVA files. Required argument.
% fg3.dirs.SAM_PATH = [fg3.dirs.data, 'lib\csamDefault\skin_hi.*, --sam_model=', fg3.dirs.data, '\csamDefault\eyeL_hi.*, --sam_model=', fg3.dirs.data, '\csamDefault\eyeR_hi.*, --sam_model=', fg3.dirs.data, '\csamDefault\teethUpper.*, --sam_model=', fg3.dirs.data, '\csamDefault\teethLower.*, --sam_model=', fg3.dirs.data, '\csamDefault\tongue.*, --sam_model=', fg3.dirs.data, '\csamDefault\sock.*'];
% fg3.dirs.DETAIL_TEXTURES_PATH = [fg3.dirs.data, '\detailTextures'];	%Directory from which to choose detail textu Defaults to detailTextures.

% to generate different expressions or orientations seed the following:
EXPRESSION_list = {fg3.generate.EXPRESSION};	% None, Anger, Disgust, Fear, Sad, Smile_Closed, Smile_Open, or Surprise
POSE_AZIMUTH_list = {-60 0 60};	% fg3.POSE_AZIMUTH
POSE_ELEVATION_list = {fg3.generate.POSE_ELEVATION fg3.generate.POSE_ELEVATION fg3.generate.POSE_ELEVATION};	% fg3.POSE_ELEVATION

% Allows specification of paths relative to this file
[parent_dir, mfile_name, mfile_ext, mfile_versn] = fileparts(mfilename('fullpath'));
cd(parent_dir);

% if no figure files specified, use FIGURE_FILE_DIR
if (~exist('figure_files', 'var'))
	dir_output = dir(fullfile(FIGURE_FILE_DIR, '*.fg'));	% only bother with actual fg files
	figure_files = {};
	for i=1:length(dir_output)
		% skip parent directory and other hidden files
		if (dir_output(i).name(1) ~= '.')
			figure_files{end + 1} = fullfile(FIGURE_FILE_DIR, dir_output(i).name);
		end
	end
else
	for i=1:length(figure_files)
		figure_files{i} = fullfile(FIGURE_FILE_DIR, figure_files{i});
	end
end

% If no output directory specified, use OUTPUT_DIR
if (~exist('output_dir', 'var'))
	output_dir = OUTPUT_DIR;
end
% Create output directory if it does not exist
if (~exist(output_dir, 'file'))
	mkdir(output_dir);
end

% open imagelists
if (write_imglist == 1),
	imglist_fd = fopen(fullfile(OUTPUT_DIR, [imglist_name, '.txt']), 'w');
	if (imglist_fd == -1),
		error('Could not create imglist, something is fishy...');
	end
	fprintf(imglist_fd, '%d\n', scale_img_2_width);
end
if (create_rf3_output) && (rf3_write_imglist == 1),
	rf3_imglist_fd = fopen(fullfile(OUTPUT_DIR, [rf3_imglist_name, '.txt']), 'w');
	if (rf3_imglist_fd == -1),
		error('Could not create imglist, something is fishy...');
	end
	fprintf(rf3_imglist_fd, '%d\n', rf3_square_size);
end

% Generate faces
for i=1:length(figure_files)
	[figure_pathstr, figure_name, figure_ext, figure_versn] = fileparts(figure_files{i});
	figure_base_name = ['ID-', figure_name];

	% allow looping over different parameters
	for i_expression = 1 : length(EXPRESSION_list)
		fg3.generate.EXPRESSION = EXPRESSION_list{i_expression};
		figure_exp_name = [figure_base_name, '_', 'EXP-', fg3.generate.EXPRESSION];
		for i_ori = 1 : length(POSE_AZIMUTH_list)
			fg3.generate.POSE_AZIMUTH = POSE_AZIMUTH_list{i_ori};
			fg3.generate.POSE_ELEVATION = POSE_ELEVATION_list{i_ori};
			figure_name = [figure_exp_name, '_', 'ORI-', 'A', num2str(fg3.generate.POSE_AZIMUTH), '-', 'E', num2str(fg3.generate.POSE_ELEVATION)];
			disp(['Processing: ', figure_files{i}, ', output: ', figure_name]);
			[status, result] = fg3('generate', fg3, figure_files{i});
			disp(['fg3 generate status: ', status']);
			if (status ~= 0),
				disp(result);
			end
			if(fg3.SAVE_DATAFILES)
				copyfile(fullfile(fg3.TMP_DIR, '000000_1.txt'), fullfile(output_dir, [figure_name, '.txt']));
			end


			if (process_img),
				% read in the image
				img = imread(fullfile(fg3.dirs.TMP_DIR, '000000_1.jpg'));
				if (create_rf3_output),
					rf3_img = img;
				end
				% TODO force RGB type if grayscale

				if (size(img, 3) == 1),
					%TODO fix me up TEST ME, basically do reverse rgb2gray here single plane?  we found a gray scale image
					tmp_img = gray2ind(img, 256);
					img = ind2rgb(tmp_img);
					convert_2_grayscale = 1;
				end

				if (replace_bg),
					img = replace_img_bg(img, bg_type, bg_img_file, fg3.generate.BACKGROUND_COLOUR, bg_fuzz, debug);
					if (debug),
						imagesc(img);
					end
				end

				%TODO squash bg color for gray scale images
				bg_color = reshape(uint8(fg3.generate.BACKGROUND_COLOUR), [1 1 3]);	% 8bit RGB
				if (debug),
					bg_color = reshape(uint8([255 0 0]), [1 1 3]) ;	% 8bit FULL RED
				end

				if (crop_img),
					img = crop_image(img, crop_height, crop_width, bg_color, debug);
				end %crop

				if (convert_2_grayscale),
					img = rgb2gray(img);
				end

				% rescale images
				if (scale_img),
					img = scale_image(img, scale_img_2_height, scale_img_2_width);
				end

				% write out img
				imwrite(img, fullfile(output_dir, [figure_name, '.jpg']), 'jpg', 'Quality', 100);

				% write images for RF3
				if (create_rf3_output),
					if (rf3_crop_img),
						rf3_img = crop_image(rf3_img, rf3_crop_height, rf3_crop_width, bg_color, debug);
					end %crop
					% rescale images
					if (rf3_scale_img),
						rf3_img = scale_image(rf3_img, rf3_scale_img_2_width, rf3_scale_img_2_width);
					end
					% do RF3 style color map processing here:
					rf3_img = conform_img_2_rf3_colorspace(rf3_img, rf3_color_palette);
					imwrite(rf3_img, fullfile(output_dir, [figure_name,'_', num2str(rf3_square_size), '.bmp']), 'bmp');
				end

			else
				% stick to the image generated by fg3
				copyfile(fullfile(fg3.dirs.TMP_DIR, '000000_1.jpg'), fullfile(output_dir, [figure_name, '.jpg']));
			end % process_images

			% write entries in image lists:
			if (write_imglist == 1),
				fprintf(imglist_fd, '%s.jpg\n', figure_name);
			end
			if (create_rf3_output) && (rf3_write_imglist == 1),
				fprintf(rf3_imglist_fd, '%s_%d.bmp\n', figure_name, rf3_square_size);
			end
		end
	end

end		% end of for loop

if (write_imglist == 1),
	disp('Closing imglist...');
	fclose(imglist_fd);
end
if (create_rf3_output) && (rf3_write_imglist == 1),
	disp('Closing rf3_imglist...');
	fclose(rf3_imglist_fd);
end

disp('Done...');
return

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function str = arg_range(number)
if(length(number) == 2)
	str = [number(1) ',' number(2)];
else
	str = num2str(number);
	str = [str ',' str];
end
return





% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [img] = scale_image(in_img, scale_img_2_height, scale_img_2_width)
% scale_image scale image to the size given by scale_img_2_height and
% scale_img_2_width, if one is set to zero, maintain aspect ratio of this
% dimension while scaleing

% only rescale if the width actually changes...
% zero means: keep aspect ratio
if ~((scale_img_2_width == 0) && (scale_img_2_height == 0)),
	if (scale_img_2_width > 0) && (scale_img_2_height == 0),
		% scale to new width while keeping aspect ratio
		img = imresize(in_img, [NaN scale_img_2_width], 'bicubic');
	elseif (scale_img_2_width == 0) && (scale_img_2_height > 0),
		% scale to new height while keeping aspect ratio
		img = imresize(in_img, [scale_img_2_height NaN], 'bicubic');
	elseif (scale_img_2_width > 0) && (scale_img_2_height > 0),
		% scale to new height and new width, potentially
		% stretching or compressing the image
		img = imresize(in_img, [scale_img_2_height scale_img_2_width], 'bicubic');
	end
end
return


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function img = crop_image(img, crop_height, crop_width, bg_color, debug)
% crop or extend the image canvas, centered; extensions will be of bg_color
% crop image or extend the canvas, relative to center, this will
% if the finalsize is not an even number of pixels smaller or
% larger than the input, the cropping will be shifted one pixel
% from the center, therefore the center error gets larger as
% the final image size gets smaller
%TODO: test with grayscale images...

img_size = size(img);	% [height widths depth]
cur_height = img_size(1);
cur_width = img_size(2);
if ~((crop_height == img_size(1)) && (crop_width == img_size(2))),	% only crop if necessary
	if (debug),
		if (crop_height > img_size(1)),
			disp('Requested crop height larger than image, padding image...');
		else
			if (crop_height < img_size(1)),
				disp('Cropping height of image');
			end
		end
		if (crop_width > img_size(2)),
			disp('Requested crop width larger than image, padding image...');
		else
			if (crop_width < img_size(1)),
				disp('Cropping width of image');
			end
		end
	end
	height_delta = crop_height - cur_height;
	d_h_U = floor(height_delta / 2);	% due to floor we might miss one row
	d_h_D = ceil(height_delta / 2);	% due to floor we might miss one row

	width_delta = crop_width - cur_width;
	d_h_R = floor(width_delta / 2);	% due to floor we might miss one row
	d_h_L = ceil(width_delta / 2);	% due to floor we might miss one row


	tmp_img = repmat(bg_color, [crop_height crop_width 1]);
	% now copy in the original image
	tmp_img(max([d_h_U 0]) + 1: d_h_U + cur_height + min([d_h_D 0]), max([d_h_L 0]) + 1: d_h_L + cur_width + min([d_h_R 0]), :) = ...
		img(abs(min([d_h_U 0])) + 1 : cur_height + min([d_h_D 0]),...
		abs(min([d_h_L 0])) + 1 : cur_width + min([d_h_R 0]),...
		:);
	img = tmp_img;
	if (debug),
		imagesc(img);
	end
end

return

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rf3_img = conform_img_2_rf3_colorspace(img, rf3_color_palette)
% map the image to the given RF3 colo palette
% initially use heuristics, best would be to actually use the color maps
% with rgb2ind
% TODO check number of planes, just assume RGB for now

switch (rf3_color_palette)
	case 'palnew'
		% all gays
		rf3_img = rgb2gray(img);
	case 'palgray'
		% all grays
		rf3_img = rgb2gray(img);
	case 'palgray32'
		img = rgb2gray(img);
		% some reserved
		n_res_col = 35;	% number of reserved colors somewhere between 32 and 40
		% only process images which use the lower n_res_col indices (0 to n_res_col - 1)
		if (min(min(img)) < n_res_col),
			%disp(['Processing: ', name]);
			img_adj = double(img);
			for color = 0:255,
				col_idx = find(img == color);
				if ~isempty(col_idx),
					% already scaled color values are negated to move them out of
					% the way, this is stupid but works...
					img_adj(col_idx) = ((color  * 255 / (255 + n_res_col)) + n_res_col) * (-1);
				end
			end
			% now make the image positive again...
			rf3_img = uint8(round(img_adj * (-1)));
		else
			rf3_img = img;
		end
	case 'palrf3_p_'
		% TODO get real colormap
	otherwise
		disp(['Unknown RF3 palette: ', rf3_color_palette]);
		disp('No colormapping performed...');
end
return

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [img] = replace_img_bg(in_img, bg_type, bg_img_file, bg_color, bg_fuzz, debug)
% replace the image background with bg_img, if bg_type = 'BACKGROUND_COLOUR'
% create a flat file
% it might be a good idea to use region growing code for that...

img = in_img;
%first segment bg from img, assume img(1,1) contains no face pixel)
img_size = size(img);
proto_bg_col = squeeze(img(1, 1, :));
tmp_proto_bg_img = repmat(reshape(proto_bg_col, [1, 1, 3]), [img_size(1) img_size(2) 1]);
tmp_bg_img = repmat(reshape(bg_color, [1, 1, 3]), [img_size(1) img_size(2) 1]);

% this works but needs a little fuzzyness
tmp_proto_bg_pixel_list = find((img(:, :, 1) == proto_bg_col(1)) & (img(:, :, 2) == proto_bg_col(2)) & (img(:, :, 3) == proto_bg_col(3)));
% fuzzy it is then, casts to double are necessary otherwise pixels with img
% < bg_color are taken as bg, which is more fuzzy then wished for
tmp_img = abs((double(img) - double(tmp_proto_bg_img)));
proto_bg_pixel_list = find(	(tmp_img(:, :, 1) <= bg_fuzz + eps) & ...
	(tmp_img(:, :, 2) <= bg_fuzz + eps) & ...
	(tmp_img(:, :, 3) <= bg_fuzz + eps));

switch bg_type
	case 'BACKGROUND_COLOUR'
		if (debug),
			bg_color = [255 0 0];
		end
		tmp_bg_img = repmat(reshape(bg_color, [1, 1, 3]), [img_size(1) img_size(2) 1]);
		img(proto_bg_pixel_list) = tmp_bg_img(proto_bg_pixel_list);
	case 'IMAGE'
		bg_img = imread(bg_img_file);
		% TODO test if size(bg_img) ~= size(img)
		bg_img_size = size(bg_img);
		if (~isequal(img_size, bg_img_size)),
			img(proto_bg_pixel_list) = bg_img(proto_bg_pixel_list);
		else
			error('Specified background image is of different size than foreground image, and that is not yet handled, aborting...');
		end
	otherwise
		error(['Unknown bg_type (', bg_type, ') specified, aborting...']);
end

return

