function [ output_args ] = mask_all_img_in_dir( input_args )
%MASK_ALL_IMG_IN_DIR apply a mask to all images in aspecific directory
%   Detailed explanation goes here

%timestamps.(mfilename).start = tic;
tic
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');
mfilepath = fileparts(fq_mfilename);

% no morphs (yet)
StimulusSet_id = ['FG_ID_distinct_IDs_frontal', '01'];	% 
set_suffix = '_01ratios';
debug = 1;


% ready this for unix systems...
[sys_status, host_name] = system('hostname');
switch host_name(1:end-1) % last char of host name result is ascii 10 (LF)
	case 'virt764'
		% virtual windows 7 64 bit under vbox on mac
		%FIGURE_FILE_DIR = fullfile('H:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'FG_generated_faces', 'swad_121017', 'Distinct_fg_faces', 'set_01', ['tweened', set_suffix]);
		img_in_dir = fullfile('H:', 'space', 'data', 'moeller', 'face_project', 'KOFIKO', 'StimulusSet', StimulusSet_id, 'images');
	case 'janus'
		%FIGURE_FILE_DIR = fullfile('C:', 'space', 'data', 'stimulation', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs', ['tweened', set_suffix]);
		img_in_dir = fullfile('C:', 'space', 'data', 'moeller', 'face_project', 'KOFIKO', 'StimulusSet', StimulusSet_id, 'images');
	%case 'KOFIKO-USER-23A'
	%case 'hms-beagle'
	otherwise
		error(['Hostname ', host_name(1:end-1), ' not handeled yet']);
end
img_out_dir = fullfile(img_in_dir, '..', 'images_masked');
if isempty(dir(img_out_dir))
	mkdir(img_out_dir);
end


img_wildcard = '*.jpg';
% find all images
image_list = dir(fullfile(img_in_dir, img_wildcard));
n_imgs = length(image_list);
% load all imgages
img_list = cell([1 n_imgs]);
ref_img = imread(fullfile(img_in_dir, image_list(1).name));
img_4d = zeros([size(ref_img), n_imgs]);
for i_img = 1 : n_imgs
	% skip directories
	if ~(image_list(i_img).isdir)
		cur_img_name = image_list(i_img).name;
		
		img_4d(:,:,:,i_img) = double(imread(fullfile(img_in_dir, cur_img_name)));
		img_list{i_img} = cur_img_name;
	end
end

img_max = 255;

% now create a mask from the image array:
%cur_img_4d = double(img_4d);
toc
mean_img = mean(img_4d/img_max, 4);
toc

toc
% do an incremental calculation of the variance, as working on with std
% will require a trip to paging hell
M2_img = zeros([size(mean_img)]);	% this is preserves state over repeated callss
for i_img = 1:length(img_list)
	cur_img = squeeze(img_4d(:,:,:,i_img)/img_max);	
	delta_img = cur_img - mean_img;
	M2_img = M2_img + (delta_img .* (cur_img - mean_img));	% the updated mean_vol!
	std_img = sqrt(M2_img / (i_img - 1));	% M2_img / (i_img - 1) is the variance
	%mean_vol = mean_vol + (tmp_mri.vol / n_in_vols); % this only gets
	%the final mean right, so not applicable as on-line mean...
end
toc
% the next if clause is just a sanaity check and quite costly...
if (false)
	std0_img = std(img_4d/img_max, 0, 4);	% this is super slow.... 
	std1_img = std(img_4d/img_max, 1, 4);	% this is super slow....
	diff0 = std_img - std0_img;
	diff1 = std_img - std1_img;
	disp(['diff 0 min: ', num2str(min(diff0(:))), ' max;', num2str(max(diff0(:)))]);
	disp(['diff 1 min: ', num2str(min(diff1(:))), ' max;', num2str(max(diff1(:)))]);
	toc
end

figure;
subplot(1, 2, 1);
imagesc(mean_img);
axis('image');
title('mean image');
subplot(1, 2, 2);
%imagesc(std_img);
imagesc(std_img /max(abs(std_img(:))));
title('stddev image');
axis('image');

% write out statistic images
imwrite(mean_img, fullfile(img_out_dir, 'stat_mean_img.png'));
imwrite(std_img, fullfile(img_out_dir, 'stat_std_img.png'));
% this set is quite variable so one mask will not fit all images, so go and
% mask individual images

% turn this into a decent mask


%timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
%disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds. Done...']);
toc
return
end

