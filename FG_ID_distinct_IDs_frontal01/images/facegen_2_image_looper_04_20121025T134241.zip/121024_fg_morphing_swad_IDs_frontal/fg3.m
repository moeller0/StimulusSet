function [ status, result ] = fg3(command, fg3_struct,  varargin )
%FG3 This function wrapps around the FaceGen SDIK's fg3 example application
%
% TODO:
%   input checking, impement input checks whenever they occur... 
global debug 
debug = 0;	% if 1 fg3.exe gets quite verbose and saves intermediates...
% allow access to the fg3 commands, as well as a simple pass through 
% also create wrappers for morphing/tweening
switch command
	case 'generate'
		%TODO check inputs,  varargin(1) is the name of the output
		[status, result] = fg3_generate(fg3_struct, varargin(1));
	case 'controls'
		% since this has sub commands just pass everything
		[status, result] = fg3_controls(fg3_struct, varargin);
    case 'passthrough'
        [status, result] = fg3_passthrough(fg3_struct, full_argument_string);
    otherwise
		error(['fg3 command ', command, ' does not exist (not implemented yet?)']);
end

if (status)
	disp(result);
end

return
end



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [status, result] = fg3_generate(fg3_strct, figure_file)
% call fg3 generate and extrect the image wuith the parameters given in the
% fg3 structure
% fg3 generate: Render and save random images of random faces (or an FG file) in various poses and expressions.
% --background_colour=[VALUE]
% --ctl_file=[VALUE]                       FaceGen statistics/distribution controls file. Defaults to si.ctl.
% --expression=[VALUE]                     Expression name (Anger, Disgust, Fear, Sad, Smile_Closed, Smile_Open, or Surprise) Defaults to None.
% --fg_file=[VALUE]                        Use this FG file instead of randomly generated faces. Defaults to none.
% --image_height=[VALUE]                   Height of generated image Defaults to 480.
% --image_width=[VALUE]                    Width of generated image Defaults to 640.
% --log_level=[VALUE]                      0 = Most, 4 = None   Defaults to 1.
% --number_from=[VALUE]                    The number to start with when numbering output files. Defaults to 0.
% --number_of_faces=[VALUE]                The number of faces to generate. Defaults to 1.
% --number_of_poses=[VALUE]                Number of poses in addition to mugshot Defaults to 9.
% --out_directory=[VALUE]                  The directory to output generated faces to. Defaults to generated-faces.
% --render_avg_face=[VALUE]                Render the mean face to
% ${out_directory}\average.jpg Defaults to 0.
% --rng_ambient_brightness=[VALUE]         Ambient brightness range. Defaults to 0.25,0.25.
% --rng_blink_coefficient=[VALUE]          Blink coefficient range Defaults to 0,0.5.
% --rng_distance=[VALUE]                   Distance from camera range Defaults to 3,5.
% --rng_head_tilt=[VALUE]                  Head tilt range.     Defaults to -10,10.
% --rng_light1_azimuth=[VALUE]             Light 1 azimuth range. Defaults to 0,0.
% --rng_light1_brightness=[VALUE]          Light 1 brightness range. Defaults to 0.5,0.5.
% --rng_light1_elevation=[VALUE]           Light 1 elevation range. Defaults to 0.2,0.2.
% --rng_light2_azimuth=[VALUE]             Light 2 azimuth range. Defaults to 10,10.
% --rng_light2_brightness=[VALUE]          Light 2 brightness range. Defaults to 0.5,0.5.
% --rng_light2_elevation=[VALUE]           Light 2 elevation range. Defaults to 0.15,0.15.
% --rng_light3_azimuth=[VALUE]             Light 3 azimuth range. Defaults to -10,-10.
% --rng_light3_brightness=[VALUE]          Light 3 brightness range. Defaults to 0.5,0.5.
% --rng_light3_elevation=[VALUE]           Light 3 elevation range. Defaults to 0.15,0.15.
% --rng_pose_azimuth=[VALUE]               Pose Azimuth range   Defaults to -45,45.
% --rng_pose_elevation=[VALUE]             Pose elevation range Defaults to 0,20.
% --rng_texture_modulation=[VALUE]         Texture modulation range Defaults to 1,1.5.
global debug 
figure_file = figure_file{1};

fg_generate_cmd_string = [fg3_strct.dirs.FG3_BIN, ' generate'];

if (isfield(fg3_strct.generate, 'BACKGROUND_COLOUR'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --background_colour=' num2str(fg3_strct.generate.BACKGROUND_COLOUR(1)), ',', num2str(fg3_strct.generate.BACKGROUND_COLOUR(2)), ',', num2str(fg3_strct.generate.BACKGROUND_COLOUR(3))];
end
if (isfield(fg3_strct.dirs, 'CTL_FILE'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --ctl_file=', fg3_strct.dirs.CTL_FILE];
end
if (isfield(fg3_strct.dirs, 'DETAIL_TEXTURES_PATH'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --detail_textures_directory=', fg3_strct.dirs.DETAIL_TEXTURES_PATH];
end
if (isfield(fg3_strct.generate, 'EXPRESSION'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --expression=', fg3_strct.generate.EXPRESSION];
end
if (~isempty(figure_file))
	% TODO check for existence???
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --fg_file=', figure_file];
end
if (isfield(fg3_strct.generate, 'IMAGE_SIZE'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --image_height=', num2str(fg3_strct.generate.IMAGE_SIZE(2))];
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --image_width=', num2str(fg3_strct.generate.IMAGE_SIZE(1))];
end
if (isfield(fg3_strct.generate, 'LOG_LEVEL'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --log_level', num2str(fg3_strct.generate.LOG_LEVEL)];
end
if (isfield(fg3_strct.generate, 'NUMBER_PIXELS_BETWEEN_EYES'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --number_pixels_between_eyes=', num2str(fg3_strct.generate.NUMBER_PIXELS_BETWEEN_EYES)];
end
if (isfield(fg3_strct.generate, 'AMBIENT_BRIGHTNESS'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_ambient_brightness=', arg_range(fg3_strct.generate.AMBIENT_BRIGHTNESS)];
end
if (isfield(fg3_strct.generate, 'BLINK_COEFFICIENT'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_blink_coefficient=', arg_range(fg3_strct.generate.BLINK_COEFFICIENT)];
end
if (isfield(fg3_strct.generate, 'DISTANCE'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_distance=', arg_range(fg3_strct.generate.DISTANCE)];
end
if (isfield(fg3_strct.generate, 'EXPRESSION_COEFFICIENT'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_expression_coefficient=', arg_range(fg3_strct.generate.EXPRESSION_COEFFICIENT)];
end
if (isfield(fg3_strct.generate, 'GAMMA'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_gamma=', arg_range(fg3_strct.generate.GAMMA)];
end
if (isfield(fg3_strct.generate, 'HEAD_TILT'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_head_tilt=', arg_range(fg3_strct.generate.HEAD_TILT)];
end
if (isfield(fg3_strct.generate, 'LIGHT1_AZIMUTH'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light1_azimuth=', arg_range(fg3_strct.generate.LIGHT1_AZIMUTH)];
end
if (isfield(fg3_strct.generate, 'LIGHT1_BRIGHTNESS'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light1_brightness=', arg_range(fg3_strct.generate.LIGHT1_BRIGHTNESS)];
end
if (isfield(fg3_strct.generate, 'LIGHT1_ELEVATION'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light1_elevation=', arg_range(fg3_strct.generate.LIGHT1_ELEVATION)];
end
if (isfield(fg3_strct.generate, 'LIGHT2_AZIMUTH'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light2_azimuth=', arg_range(fg3_strct.generate.LIGHT2_AZIMUTH)];
end
if (isfield(fg3_strct.generate, 'LIGHT2_BRIGHTNESS'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light2_brightness=', arg_range(fg3_strct.generate.LIGHT2_BRIGHTNESS)];
end
if (isfield(fg3_strct.generate, 'LIGHT2_ELEVATION'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light2_elevation=', arg_range(fg3_strct.generate.LIGHT2_ELEVATION)];
end
if (isfield(fg3_strct.generate, 'LIGHT3_AZIMUTH'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light3_azimuth=', arg_range(fg3_strct.generate.LIGHT3_AZIMUTH)];
end
if (isfield(fg3_strct.generate, 'LIGHT3_BRIGHTNESS'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light3_brightness=', arg_range(fg3_strct.generate.LIGHT3_BRIGHTNESS)];
end
if (isfield(fg3_strct.generate, 'LIGHT3_ELEVATION'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_light3_elevation=', arg_range(fg3_strct.generate.LIGHT3_ELEVATION)];
end
if (isfield(fg3_strct.generate, 'POSE_AZIMUTH'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_pose_azimuth=', arg_range(fg3_strct.generate.POSE_AZIMUTH)];
end
if (isfield(fg3_strct.generate, 'POSE_ELEVATION'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_pose_elevation=', arg_range(fg3_strct.generate.POSE_ELEVATION)];
end
if (isfield(fg3_strct.generate, 'TEXTURE_MODULATION'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --rng_texture_modulation=', arg_range(fg3_strct.generate.TEXTURE_MODULATION)];
end
if (isfield(fg3_strct.dirs, 'SAM_PATH'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --sam_model=', fg3_strct.dirs.SAM_PATH];
end
if (isfield(fg3_strct.generate, 'SAVE_DATAFILES'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --save_datafiles=', num2str(fg3_strct.generate.SAVE_DATAFILES)];
end
if (isfield(fg3_strct.generate, 'SEED'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --seed=', num2str(fg3_strct.generate.SEED)];
end
if (isfield(fg3_strct.generate, 'SHRINK_FACTOR'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --shrink_factor=', num2str(fg3_strct.generate.SHRINK_FACTOR)];
end
if (isfield(fg3_strct.dirs, 'TMP_DIR'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --out_directory=', fg3_strct.dirs.TMP_DIR];
end
if (isfield(fg3_strct.generate, 'N_POSES'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --number_of_poses=', num2str(fg3_strct.generate.N_POSES)];
end
if (isfield(fg3_strct.generate, 'MUGSHOT'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --render_mugshot=', num2str(fg3_strct.generate.MUGSHOT)];
end
if (isfield(fg3_strct.generate, 'N_FACES'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --number_of_faces=', num2str(fg3_strct.generate.N_FACES)];
end
if (isfield(fg3_strct.generate, 'AVG_FACE'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --render_avg_face=', num2str(fg3_strct.generate.AVG_FACE)];
end
if (isfield(fg3_strct.generate, 'FROM'))
	fg_generate_cmd_string = [fg_generate_cmd_string, ' --number_from=', num2str(fg3_strct.generate.FROM)];
end

%[status, result] = dos([fg_generate_cmd_string], '-echo');
disp(fg_generate_cmd_string);
[status, result] = system(fg_generate_cmd_string, '-echo');
return
end


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [status, result] = fg3_controls(fg3_strct, varargin)
% controls <controls>.ctl <FaceInfo>.fg <Output>.fg
%   { age <Race> {shape|texture} <Age>                                       |
%     gender <Race> {shape|texture} <Gender>                                 |
%     caricature <Race> {shape|texture} <Caricature>                         |
%     asymmetry <Race> <Asymmetry>                                           |
%     race <FromRace> <DestRace> <RaceTween>                                 |
%     shapeCtl {symm|asym} <CtrlId> <Pos>                                    |
%     textureCtl {symm|asym} <CtrlId> <Pos>                                  |
%     random <Race>                                                          |
%     tween <TargetFaceInfo>.fg <ShapeRatio> <TextureRatio> <AsymmetryRatio> |
%     geneticRandom <randomness> }
% 
%  <Age>: 15 to 65
%  <Gender>: -4 = very male, -1 = male, 1 = female, etc.
%  <Caricature>: 0 = The average, 1 = typical, 2 = caricature, etc
%  <Asymmetry>: 0 = Symmetric, 1 = typical, etc.
%  <Race>/<FromRace>/<DestRace>: all | african | european | seAsian | eIndian
%  <RaceTween>: -1 for "FromRace", 1 for "DestRace"
% 
%  {shape|texture}: 'shape' will modify the geometry, 'texture' the texture.
%
% TODO
%   implement sub controls as needed
%
global debug 

% mandatory variables
var_args = varargin{1};
FaceInfo_fg = var_args{1};
Output_fg = var_args{2};
cur_control = var_args{3};

fg_controls_cmd_string = [fg3_strct.dirs.FG3_BIN, ' ', 'controls', ' ', fg3_strct.dirs.CTL_FILE, ' ', FaceInfo_fg, ' ' , Output_fg];


switch cur_control
	case 'tween'
		TargetFaceInfo_fg = var_args{4};
        if nargin <= 6
            % tween all Ratios equally
            ShapeRatio = var_args{5};
            TextureRatio = var_args{5}; 
            AsymmetryRatio = var_args{5};
			DetailTextureRatio = var_args{5};
            disp('Using equal ratio for shape, texture, asymmetry, and detail texture tweening...');
        else
            % tween Ratios independently
            ShapeRatio = var_args{5};
            TextureRatio = var_args{6}; 
            AsymmetryRatio = var_args{7};
			DetailTextureRatio = var_args{5};
        end
        fg_controls_cmd_string = [fg_controls_cmd_string, ' ', cur_control, ' ', TargetFaceInfo_fg, ' ',...
									num2str(ShapeRatio), ' ', ...
									num2str(TextureRatio), ' ', ...
									num2str(AsymmetryRatio), ' ', ...
									num2str(DetailTextureRatio)];
        
        
	otherwise
		error(['Control ', cur_control, ' not implemented yet.']);
end
% if (isfield(fg3_strct.contols, 'FROM'))
% 	fg_controls_cmd_string = [fg_controls_cmd_string, ' --number_from=', num2str(fg3_strct.generate.FROM)];
% end

fg_controls_cmd_string = [fg_controls_cmd_string, ' ', num2str(debug)];

disp(fg_controls_cmd_string);
[status, result] = system(fg_controls_cmd_string, '-echo');

return
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [status, result] = fg3_passthrough(fg3_strct, full_argument_string)
% just pass through a string of arguments to fg3, mainly for testing
global debug 

% assemble the command line invocation for fg3
fg_controls_cmd_string = [fg3_strct.dirs.FG3_BIN, ' ', full_argument_string];
% actually call out to fg3
[status, result] = system(fg_controls_cmd_string, '-echo');

return
end


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function str = arg_range(number)
if(length(number) == 2)
	str = [number(1) ',' number(2)];
else
	str = num2str(number);
	str = [str ',' str];
end
return
end
