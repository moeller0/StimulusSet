%function [ output_args ] = test_fn_handle_fg_models( input_args )
%TEST_FN_HANDLE_FG_MODELS Summary of this function goes here
%   Detailed explanation goes here

% read in two existing models
[tmp1,tmp1raw]  = fn_handle_fg_models('read', '01_121015..fg');
[tmp2,tmp2raw]  = fn_handle_fg_models('read', 'MS_120130_2_SN_120130-TRF_tweened_000.0pct..fg');
% test writing
stat = fn_handle_fg_models('write', fullfile(pwd, 'model_without_texture.fg'), tmp1);
% read the just writen model back in
tmp3 = fn_handle_fg_models('read', 'model_without_texture.fg');
disp(['Symmetric shape parameters equal?; ', num2str(isequal(tmp1.coordGa, tmp3.coordGa))]);
disp(['Asymmetric shape parameters equal?; ', num2str(isequal(tmp1.coordGs, tmp3.coordGs))]);
disp(['Symmetric texture parameters equal?; ', num2str(isequal(tmp1.coordTa, tmp3.coordTa))]);
disp(['Asymmetric texture parameters equal?; ', num2str(isequal(tmp1.coordTs, tmp3.coordTs))]);

% test texture transplant
tmp4 = tmp1;
tmp4.detailTexJpeg = tmp2.detailTexJpeg;
stat = fn_handle_fg_models('write', fullfile(pwd, 'model_of_01_121015_with_texture_from_MS_120130_2_SN_120130-TRF_tweened_000.0pct.fg'), tmp4);

disp(['Please open and check ', fullfile(pwd, 'model_of_01_121015_with_texture_from_MS_120130_2_SN_120130-TRF_tweened_000.0pct.fg'), ' in FaceGen Modeller...']);
