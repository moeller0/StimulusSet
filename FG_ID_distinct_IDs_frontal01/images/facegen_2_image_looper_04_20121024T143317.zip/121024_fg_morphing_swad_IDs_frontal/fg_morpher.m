function [ output_args ] = fg_morpher( input_src, out_dir, ratio_list, varargin)
%FG_MORPHER simple wrapper for creating tweenings between all combination
% of an input fg model list for the specified intermediates ratios
%   Detailed explanation goes here
% ratio_list is a list with the ratios for which to create tweened models
timestamps.(mfilename).start = tic;
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');
mfilepath = fileparts(fq_mfilename);

fg3_struct.dirs = fg3_define_dirs;
if ~isdir(out_dir)
	mkdir(out_dir);
end


% input_src is either a directory than pick all fg models inside or a list
% of fg models with relative pathes
if isdir(input_src)
	proto_model_list = dir(fullfile(input_src, '*.fg'));
	fg_list = cell(size(proto_model_list));
	for i_model = 1 : size(proto_model_list ,1)
		fg_list{i_model} = proto_model_list(i_model).name;
		fg_fqn_list{i_model} = fullfile(input_src, proto_model_list(i_model).name);
	end
	% create all combinations of two models
	model_combinations_matrix = nchoosek((1:1:length(fg_list)), 2);

else
	disp('NIY');
	% either a list of fg_fqns or a table giving 2 fg models per row to
	% give the morph-line endpoints
	% needs to create the fg_list and the model_combinations_matrix...
end


% get the current tween-line's endpoints
for i_combination = 1 : size(model_combinations_matrix, 1)
	disp(['Processing the ', num2str(i_combination), '. combination of ', num2str(size(model_combinations_matrix, 1))]);
	from_fg = fg_fqn_list{model_combinations_matrix(i_combination, 1)};
	to_fg = fg_fqn_list{model_combinations_matrix(i_combination, 2)};
	disp(['From: ', from_fg, ' To: ', to_fg]);
	fg.from = read_fg(from_fg);
	fg.to = read_fg(to_fg);
	
	% create the morph line between two identities
	for i_ratio = 1: length(ratio_list)
		cur_ratio = ratio_list(i_ratio);
		out_fg = fullfile(out_dir, [fg_list{model_combinations_matrix(i_combination, 1)}(1:end-3) '_2_', ...
									fg_list{model_combinations_matrix(i_combination, 2)}(1:end-3), '-', 'TRF_tweened','_', num2str((1 - cur_ratio) * 100, '%05.1f'), 'pct', '.', 'fg']);
		[ status, result ] = fg3('controls', fg3_struct,  from_fg, out_fg, 'tween', to_fg, cur_ratio);

		fg.(['ratio', num2str(round(cur_ratio * 100), '%03d')]) = read_fg(out_fg);
	end
end

timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds. Done...']);
return
end


