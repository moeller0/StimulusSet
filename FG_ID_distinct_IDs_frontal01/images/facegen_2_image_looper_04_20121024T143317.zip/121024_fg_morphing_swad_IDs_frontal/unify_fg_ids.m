function [] = unify_fg_ids()
% originally we collected images from several sources and used facegen's
% photofit to generate models, keeping the original ID specifiers.
% Now it seems prident to create canonical names from which information can
% be easily parsed.
% Scheme:	Species	Gender	Race	Source	ID-num	Repeat-num	Name
% Code:		1L		1L		1L		2L		4N		2N			*L
% in the future all new fg should be named after the new convention
% TODO:
%	make work
%	write parser for new canonical IDs
% DONE:

calling_dir = pwd;
in_dir = fullfile(calling_dir, 'lib', 'good_models');
out_dir = fullfile(calling_dir, 'lib', 'IDs');
id_mapping_file = 'origID_2_canonicalID.txt';
debug = 1;

if ~isdir(out_dir),
	mkdir(out_dir);
end

im_fh = fopen(fullfile(out_dir, id_mapping_file), 'w');
if (im_fh == -1),
	error(['Could not create ', fullfile(out_dir, id_mapping_file)]);
end
fprintf(im_fh, '## Scheme:	Species	Gender	Race	Source	ID-num	- Repeat-num	Name\n');
fprintf(im_fh, '## Code:	1L		1L		1L		2L		4N		- 2N			*L\n');
fprintf(im_fh, '## Species\n');
fprintf(im_fh, '# H: human\n');
fprintf(im_fh, '# M: macaca mulatta\n');
fprintf(im_fh, '# O: object\n');
fprintf(im_fh, '## Gender\n');
fprintf(im_fh, '# M: male\n');
fprintf(im_fh, '# F: female\n');
fprintf(im_fh, '# N: none\n');
fprintf(im_fh, '## Race\n');			% we inherited this from Micheal J. Tarr's face-place
fprintf(im_fh, '# A: asian\n');		% SE asian in FG
fprintf(im_fh, '# B: black\n');		% afrikan in FG
fprintf(im_fh, '# C: caucasian\n');	% european in FG
fprintf(im_fh, '# I: indian\n');		% E indian in FG
fprintf(im_fh, '# H: hispanic\n');
fprintf(im_fh, '# M: mixed\n');
fprintf(im_fh, '# U: unspecified\n');
fprintf(im_fh, '# O: object, see Name field\n');		% put name on Name field
fprintf(im_fh, '# Z: animal, see Name field\n');		% put name on Name field
fprintf(im_fh, '## Source\n');
fprintf(im_fh, '# HB: Bremen, tsao lab\n');
fprintf(im_fh, '# CT: Caltech, tsao lab\n');
fprintf(im_fh, '# FG: facegen generated, SM\n');
fprintf(im_fh, '# MP: MPI for biological Kybernetics Tuebingen, Buelthoff lab\n');
fprintf(im_fh, '# FP: Face-Place, Micheal J. Tarr lab\n');
fprintf(im_fh, '# \n');

fg_list = dir(fullfile(in_dir, '*.fg'));

for i_fg = 1:length(fg_list)
	repnum = 1;		% assume that all IDs apear only once (true for the initial set...)
	cur_in_name = fg_list(i_fg).name;
	if (debug)
		disp(['Current fg file: ', cur_in_name]);
	end
	% now parse the ID format, and generate the Codes
	[parsed] = parse_fg_name(cur_in_name);	
	
	cur_out_name = [parsed.species, parsed.gender, parsed.race, parsed.source, num2str(i_fg, '%04d'), '-', num2str(repnum, '%02d'), parsed.name, '.fg'];
	% store the mapping, as tab separated:
	fprintf(im_fh, '%s\t%s\n', cur_out_name, cur_in_name);
	% copy the fg file
	copyfile(fullfile(in_dir, cur_in_name), fullfile(out_dir, cur_out_name));
	
end
% clean up
fclose(im_fh);
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [parsed] = parse_fg_name(fg_name)
% parse the wildly differing file names from the different sorces, extract
% or substitute missing information...

% for the current set the first three charcters determine the source
ID_string = fg_name(1:3);

switch ID_string
	case 'MPI'
		parsed.source = 'MP';
		parsed.species = 'H';
		parsed.gender = upper(fg_name(4));
		parsed.race = 'C';
		parsed.name = 'Hum';
	case 'HB_'
		parsed.source = 'HB';
		if (strcmp('.', fg_name(6)) || strcmp('_', fg_name(6))),
			% human
			parsed.species = 'H';
			parsed.name = 'Hum';
			% these differ and have to be taken from a table
			initials = fg_name(4:5);
			parsed.race = 'C';		
			switch initials
				case 'fw'
					parsed.gender = 'M';
				case 'hr'
					parsed.gender = 'M';
					parsed.race = 'B';		
				case 'mi'
					parsed.gender = 'M';
				case 'ms'
					parsed.gender = 'M';
				case 'na'
					parsed.gender = 'F';
				case 'sh'
					parsed.gender = 'M';
				case 'sn'
					parsed.gender = 'F';
				case 'sw'
					parsed.gender = 'F';
			end
		else
			% monkey
			parsed.species = 'M';
			parsed.gender = 'M';
			parsed.race = 'Z';
			parsed.name = 'Mac';
		end
	case 'CIT'
		parsed.source = 'CT';
		parsed.species = 'M';
		parsed.gender = 'M';
		parsed.race = 'Z';
		parsed.name = 'Mac';
	otherwise
		% this defaults to face-place
		parsed.source = 'FP';
		parsed.species = 'H';
		parsed.gender = upper(fg_name(2));
		parsed.race = upper(fg_name(1));
		parsed.name = 'Hum';
end

disp('Done...');

return
