function [ output_args ] = tween_tester( input_args )
%TWEEN_TESTER Summary of this function goes here
%   Detailed explanation goes here


src_dir = fullfile('F:', 'face_project', 'stim_cit', 'FACE_COLLECTIONS', 'CIT_familiar_faces', 'familiar_2012_fg_models', '4famIDs');
out_dir = fullfile(src_dir, 'tweens');

fg_morpher(src_dir, out_dir, [0.0, 0.1667, 0.3333, 0.5, 0.6667, 0.8333, 1.0]);
%fg_morpher(src_dir, out_dir, [0.0]);

return
end