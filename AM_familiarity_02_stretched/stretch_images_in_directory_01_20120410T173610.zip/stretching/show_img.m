function [ fig_handle ] = show_img(name, image, opts)
% take care to show images

if nargin < 3
	opts.colormap_gray = 0;
	opts.show_gray_as_rgb = 1;
end	

% to make everything 
if (size(image, 3) == 1) && (opts.show_gray_as_rgb)
	image = repmat(image, [1, 1, 3]);
end


fig_handle = figure('Name', name);
% in case the image is 8bit converted to double, convert it back
% alternatively, scale it into the zero to one range (but we need to know the theoretical max velue)
if strcmp(class(image), 'double') && max(image(:)) > 1 && max(image(:)) <= 255
	image = uint8(image);
end

imagesc(image);
axis equal;
if (size(image, 3) == 1) && opts.colormap_gray
	colormap(gray)
end



return
end