function [img] = ms_scale_image(in_img, scale_img_2_height, scale_img_2_width)
% ms_scale_image: scale image to the size given by scale_img_2_height and
% scale_img_2_width, if one is set to zero, maintain aspect ratio of this
% dimension while scaleing
% simple wrapper for imresize
% TODO: also allow a simple scaling factor for simple scaling of height and
% width


% only rescale if the width actually changes...
% zero means: keep aspect ratio
if ~((scale_img_2_width == 0) && (scale_img_2_height == 0)),
	if (scale_img_2_width > 0) && (scale_img_2_height == 0),
		% scale to new width while keeping aspect ratio
		img = imresize(in_img, [NaN scale_img_2_width], 'bicubic');
	elseif (scale_img_2_width == 0) && (scale_img_2_height > 0),
		% scale to new height while keeping aspect ratio
		img = imresize(in_img, [scale_img_2_height NaN], 'bicubic');
	elseif (scale_img_2_width > 0) && (scale_img_2_height > 0),
		% scale to new height and new width, potentially
		% stretching or compressing the image
		img = imresize(in_img, [scale_img_2_height scale_img_2_width], 'bicubic');
	end
end
return


