function [ output_args ] = stretch_images_in_directory_01( input_args )
%NOISE_TESTER_01 Summary of this function goes here
% TODO:
%	stretching
%	facegen morphing (in this script???)


timestamps.(mfilename).start = tic;
disp(['Starting: ', mfilename]);
dbstop if error
fq_mfilename = mfilename('fullpath');
mfilepath = fileparts(fq_mfilename);

close all

% control variables
save_code = 1;

% stretching
opts.stretch.do_stretch = 1;	% scale the image height by the widths and height list
opts.stretch.height_factor_list = [1, 1, 1, 1];			% coordinated lists
opts.stretch.widths_factor_list = [1, 0.6, 0.3, 0.1];	% coordinated lists
opts.stretch.background = [128 128 128];		% which background to use to fill the missing pixels in, either color spec or (fq) image file name


% DIRECTORIES and file namesKofiko style StimulusSets
inputs.stimset_name = 'AM_familiarity_02';	% the final directory whe
inputs.filenamewildcard = '*.jpg';
outputs.stimset_name = [inputs.stimset_name, '_stretched'];
outputs.filetype = '.jpg';
if ismac
	inputs.dir = fullfile('/', 'space', 'data', 'moeller', 'face_project', 'KOFIKO', 'StimulusSet', inputs.stimset_name);
else
	inputs.dir = fullfile('C:', 'space', 'data', 'moeller', 'KOFIKO', 'StimulusSet', inputs.stimset_name);
end
outputs.dir = fullfile(fileparts(inputs.dir), outputs.stimset_name);
%outputs.mask_dir = fullfile(outputs.dir, 'MASKS');	% where to look for precanned masks and where to store each produced mask

% collect all images in the inputs.dir
proto_img_list = dir(fullfile(inputs.dir, inputs.filenamewildcard));
if isempty(proto_img_list)
	disp('No images found, exiting...');
	return
end
tmp_img = imread(fullfile(inputs.dir, proto_img_list(1).name));
inputs.imgsize = size(tmp_img);
inputs.imgclass = class(tmp_img);


% loop over all images, all opts.mask.type_list and all opts.mask.pct_list to create the masked
% images in sub directories
% start with images to keep memory load low
for i_in_img = 1 : length(proto_img_list)
	cur_in_img_name = fullfile(inputs.dir, proto_img_list(i_in_img).name);
	cur_in_img = imread(cur_in_img_name);
	
	if opts.stretch.do_stretch
		disp(['stretching: ', cur_in_img_name]);
		cur_out_dir = fullfile(outputs.dir, 'stretched');
		if isempty(dir(cur_out_dir))
			disp(['Creating target directory: ', cur_out_dir]);
			mkdir(cur_out_dir);
		end
		for i_stretch_factor = 1 : length(opts.stretch.widths_factor_list)
			cur_stretch_height_pix = round(opts.stretch.height_factor_list(i_stretch_factor) * size(cur_in_img, 1));
			cur_stretch_widths_pix = round(opts.stretch.widths_factor_list(i_stretch_factor) * size(cur_in_img, 2));
			% scale the image to the new size, anisotrop scaling equals
			% stretching...
			stretched_img_canvas = ms_scale_image(cur_in_img, cur_stretch_height_pix, cur_stretch_widths_pix);
			% now extend the canvas back again
			stretched_img_arr = ms_crop_image(stretched_img_canvas, size(cur_in_img, 1), size(cur_in_img, 2), opts.stretch.background);

			% save out the masked immage
			imwrite(stretched_img_arr, fullfile(cur_out_dir, ['stretched_', 'h', num2str(opts.stretch.height_factor_list(i_stretch_factor) * 100, '%03d'), 'pct', ...
																						'_w' num2str(opts.stretch.widths_factor_list(i_stretch_factor) * 100, '%03d'), 'pct',...
																						'.',  proto_img_list(i_in_img).name]));

		end		% i_stretch_factor
		
	end		% do_stretch
end		% in_imb

% saving the code that generated the outpput into the output directory...
if (save_code)
	disp('Saving all matlab code that generated the outputs into the output directory');
	mfile_fqn = mfilename('fullpath');
	code_dir = fileparts(mfile_fqn);
	% save the code in a versioned directory...
	%gzip(code_dir, fullfile(dirs.out_img_lists, [mfilename, '_',
	%datestr(clock, 30)]));	% this compressed each file individually
	zip(fullfile(outputs.dir, [mfilename, '_', datestr(clock, 30), '.zip']), code_dir); % compresses all files into one archive
end

timestamps.(mfilename).end = toc(timestamps.(mfilename).start);
disp([mfilename, ' took: ', num2str(timestamps.(mfilename).end), ' seconds. Done...']);
return
end

